"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-slate-950/90 backdrop-blur-md shadow-lg" : ""
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          <Link href="/" className="flex items-center">
            <span className="text-2xl font-bold uppercase tracking-wider">
              VEX
              <span className="text-purple-500 relative after:content-[''] after:absolute after:w-full after:h-1 after:bg-gradient-to-r after:from-purple-500 after:to-pink-500 after:bottom-0 after:left-0 after:rounded-full">
                OS
              </span>
            </span>
          </Link>

          <nav
            className={`fixed md:relative top-0 left-0 right-0 bottom-0 md:top-auto md:left-auto md:right-auto md:bottom-auto h-screen md:h-auto bg-slate-950/95 md:bg-transparent backdrop-blur-md md:backdrop-filter-none z-50 md:z-auto transition-all duration-300 ${
              isMenuOpen ? "flex flex-col items-center justify-center" : "hidden md:block"
            }`}
          >
            <ul className="flex flex-col md:flex-row items-center gap-8 md:gap-6">
              <li>
                <Link
                  href="#features"
                  className="font-medium hover:text-purple-500 transition-colors relative after:content-[''] after:absolute after:w-0 after:h-0.5 after:bg-gradient-to-r after:from-purple-500 after:to-pink-500 after:bottom-0 after:left-0 hover:after:w-full after:transition-all"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Features
                </Link>
              </li>
              <li>
                <Link
                  href="#key-system"
                  className="font-medium hover:text-purple-500 transition-colors relative after:content-[''] after:absolute after:w-0 after:h-0.5 after:bg-gradient-to-r after:from-purple-500 after:to-pink-500 after:bottom-0 after:left-0 hover:after:w-full after:transition-all"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Key System
                </Link>
              </li>
              <li>
                <Link
                  href="#api"
                  className="font-medium hover:text-purple-500 transition-colors relative after:content-[''] after:absolute after:w-0 after:h-0.5 after:bg-gradient-to-r after:from-purple-500 after:to-pink-500 after:bottom-0 after:left-0 hover:after:w-full after:transition-all"
                  onClick={() => setIsMenuOpen(false)}
                >
                  API
                </Link>
              </li>
              <li>
                <Link
                  href="#download"
                  className="font-medium hover:text-purple-500 transition-colors relative after:content-[''] after:absolute after:w-0 after:h-0.5 after:bg-gradient-to-r after:from-purple-500 after:to-pink-500 after:bottom-0 after:left-0 hover:after:w-full after:transition-all"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Download
                </Link>
              </li>
            </ul>
          </nav>

          <div className="flex items-center gap-4">
            <Button className="hidden md:flex bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              Login
            </Button>

            <button className="block md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}

