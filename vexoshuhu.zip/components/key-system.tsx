"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle, Copy, ExternalLink, Clock, RefreshCw, Key } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export default function KeySystem() {
  const [currentStep, setCurrentStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const [generatedKey, setGeneratedKey] = useState("")
  const [stepStatus, setStepStatus] = useState({
    1: "pending", // pending, loading, completed
    2: "pending",
    3: "pending",
    4: "pending",
  })

  const totalSteps = 4
  const progress = (Object.values(stepStatus).filter((status) => status === "completed").length / totalSteps) * 100

  const handleStepAction = (step: number) => {
    setIsLoading(true)

    // Simulate API call or verification process
    setTimeout(() => {
      setStepStatus({
        ...stepStatus,
        [step]: "completed",
      })

      if (step < totalSteps) {
        setCurrentStep(step + 1)
      } else {
        // Generate a random key when all steps are completed
        const randomKey = `VEXOS-${Math.random().toString(36).substring(2, 8).toUpperCase()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`
        setGeneratedKey(randomKey)
      }

      setIsLoading(false)
    }, 2000)
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedKey)
    alert("Key copied to clipboard!")
  }

  const resetKeySystem = () => {
    setCurrentStep(1)
    setGeneratedKey("")
    setStepStatus({
      1: "pending",
      2: "pending",
      3: "pending",
      4: "pending",
    })
  }

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 md:p-8 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold">Key Generation Progress</h3>
          <span className="text-sm text-slate-400">{Math.round(progress)}% Complete</span>
        </div>

        <Progress value={progress} className="h-2 mb-8" />

        {generatedKey ? (
          <div className="text-center py-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-purple-500/20 text-purple-500 mb-4">
              <Key size={32} />
            </div>
            <h3 className="text-xl font-bold mb-2">Your Key Has Been Generated!</h3>
            <p className="text-slate-400 mb-6">Use this key to activate your VEXOS Executor</p>

            <div className="flex items-center justify-center mb-8">
              <div className="bg-slate-950 rounded-lg px-6 py-3 font-mono text-purple-400 border border-purple-500/30 flex items-center">
                {generatedKey}
                <button onClick={copyToClipboard} className="ml-3 text-slate-400 hover:text-white transition-colors">
                  <Copy size={16} />
                </button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                Download Executor
              </Button>
              <Button variant="outline" onClick={resetKeySystem}>
                <RefreshCw className="mr-2 h-4 w-4" />
                Generate New Key
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <StepItem
              number={1}
              title="Visit Our First Ad Link"
              description="Click the button below to visit our first ad link. Stay on the page for at least 10 seconds."
              status={stepStatus[1]}
              isActive={currentStep === 1}
              isLoading={isLoading && currentStep === 1}
              onAction={() => handleStepAction(1)}
              buttonText="Visit Ad Link #1"
            />

            <StepItem
              number={2}
              title="Complete Second Ad Link"
              description="Visit our second ad link and complete the required action to proceed."
              status={stepStatus[2]}
              isActive={currentStep === 2}
              isLoading={isLoading && currentStep === 2}
              onAction={() => handleStepAction(2)}
              buttonText="Visit Ad Link #2"
            />

            <StepItem
              number={3}
              title="Join Our Discord Server"
              description="Join our Discord community to get support and updates about VEXOS."
              status={stepStatus[3]}
              isActive={currentStep === 3}
              isLoading={isLoading && currentStep === 3}
              onAction={() => handleStepAction(3)}
              buttonText="Join Discord"
            />

            <StepItem
              number={4}
              title="Verify Your Identity"
              description="Complete a quick verification to prove you're human and generate your key."
              status={stepStatus[4]}
              isActive={currentStep === 4}
              isLoading={isLoading && currentStep === 4}
              onAction={() => handleStepAction(4)}
              buttonText="Verify & Generate Key"
            />
          </div>
        )}
      </div>

      <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 md:p-8">
        <h3 className="text-xl font-bold mb-4">Key System Information</h3>
        <ul className="space-y-3 text-slate-400">
          <li className="flex items-start">
            <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0 mt-0.5" />
            <span>Each key is valid for 24 hours after generation</span>
          </li>
          <li className="flex items-start">
            <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0 mt-0.5" />
            <span>Keys are tied to your hardware ID for security</span>
          </li>
          <li className="flex items-start">
            <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0 mt-0.5" />
            <span>Premium users can generate keys without ads</span>
          </li>
          <li className="flex items-start">
            <XCircle className="h-5 w-5 text-red-500 mr-2 shrink-0 mt-0.5" />
            <span>Do not share your key with others - this will result in a ban</span>
          </li>
          <li className="flex items-start">
            <XCircle className="h-5 w-5 text-red-500 mr-2 shrink-0 mt-0.5" />
            <span>Using VPNs or proxies during key generation is not allowed</span>
          </li>
        </ul>
      </div>
    </div>
  )
}

interface StepItemProps {
  number: number
  title: string
  description: string
  status: string
  isActive: boolean
  isLoading: boolean
  onAction: () => void
  buttonText: string
}

function StepItem({ number, title, description, status, isActive, isLoading, onAction, buttonText }: StepItemProps) {
  return (
    <div
      className={`border rounded-lg p-4 transition-all ${
        isActive
          ? "border-purple-500 bg-purple-500/10"
          : status === "completed"
            ? "border-green-500/30 bg-green-500/5"
            : "border-slate-800 bg-slate-900/30"
      }`}
    >
      <div className="flex items-start">
        <div
          className={`flex items-center justify-center w-8 h-8 rounded-full mr-3 shrink-0 ${
            status === "completed"
              ? "bg-green-500/20 text-green-500"
              : isActive
                ? "bg-purple-500/20 text-purple-500"
                : "bg-slate-800 text-slate-400"
          }`}
        >
          {status === "completed" ? <CheckCircle size={16} /> : <span>{number}</span>}
        </div>

        <div className="flex-1">
          <h4 className="font-medium mb-1">{title}</h4>
          <p className="text-sm text-slate-400 mb-4">{description}</p>

          {isActive && (
            <Button
              onClick={onAction}
              disabled={isLoading}
              className="w-full sm:w-auto bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <ExternalLink className="mr-2 h-4 w-4" />
                  {buttonText}
                </>
              )}
            </Button>
          )}

          {status === "completed" && (
            <span className="inline-flex items-center text-sm text-green-500">
              <CheckCircle className="mr-1 h-4 w-4" />
              Completed
            </span>
          )}

          {!isActive && status === "pending" && (
            <span className="inline-flex items-center text-sm text-slate-500">
              <Clock className="mr-1 h-4 w-4" />
              Waiting
            </span>
          )}
        </div>
      </div>
    </div>
  )
}

