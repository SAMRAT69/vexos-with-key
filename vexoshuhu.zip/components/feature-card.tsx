import type { ReactNode } from "react"

interface FeatureCardProps {
  icon: ReactNode
  title: string
  description: string
}

export default function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 transition-all duration-300 hover:transform hover:scale-105 hover:shadow-xl hover:shadow-purple-500/10 hover:border-purple-500/30 group">
      <div className="mb-4 transition-transform duration-300 group-hover:scale-110 group-hover:text-purple-400">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-3 relative inline-block">
        {title}
        <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-purple-500 to-transparent group-hover:w-full transition-all duration-300"></span>
      </h3>
      <p className="text-slate-400">{description}</p>
    </div>
  )
}

