import Link from "next/link"
import { Github, Twitter, DiscIcon as Discord, Youtube } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-900 pt-16 pb-8 relative">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(124,58,237,0.1)_0%,transparent_70%)] z-0"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="text-2xl font-bold uppercase tracking-wider mb-4">
              VEX
              <span className="text-purple-500 relative after:content-[''] after:absolute after:w-full after:h-1 after:bg-gradient-to-r after:from-purple-500 after:to-pink-500 after:bottom-0 after:left-0 after:rounded-full">
                OS
              </span>
            </div>
            <p className="text-slate-400 mb-6">
              Revolutionizing the Roblox experience with cutting-edge execution technology and an innovative user
              interface.
            </p>
            <div className="flex space-x-4">
              <Link
                href="#"
                className="w-10 h-10 rounded-full bg-slate-900/80 flex items-center justify-center text-slate-400 hover:bg-purple-500 hover:text-white transition-colors"
              >
                <Twitter size={18} />
              </Link>
              <Link
                href="#"
                className="w-10 h-10 rounded-full bg-slate-900/80 flex items-center justify-center text-slate-400 hover:bg-purple-500 hover:text-white transition-colors"
              >
                <Discord size={18} />
              </Link>
              <Link
                href="#"
                className="w-10 h-10 rounded-full bg-slate-900/80 flex items-center justify-center text-slate-400 hover:bg-purple-500 hover:text-white transition-colors"
              >
                <Youtube size={18} />
              </Link>
              <Link
                href="#"
                className="w-10 h-10 rounded-full bg-slate-900/80 flex items-center justify-center text-slate-400 hover:bg-purple-500 hover:text-white transition-colors"
              >
                <Github size={18} />
              </Link>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4 relative inline-block">
              Navigation
              <span className="absolute bottom-0 left-0 w-8 h-0.5 bg-gradient-to-r from-purple-500 to-transparent"></span>
            </h4>
            <ul className="space-y-2">
              <li>
                <Link
                  href="#home"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  Home
                </Link>
              </li>
              <li>
                <Link
                  href="#features"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  Features
                </Link>
              </li>
              <li>
                <Link
                  href="#key-system"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  Key System
                </Link>
              </li>
              <li>
                <Link
                  href="#api"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  API
                </Link>
              </li>
              <li>
                <Link
                  href="#download"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  Download
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4 relative inline-block">
              Support
              <span className="absolute bottom-0 left-0 w-8 h-0.5 bg-gradient-to-r from-purple-500 to-transparent"></span>
            </h4>
            <ul className="space-y-2">
              <li>
                <Link
                  href="https://discord.gg/2hx9atQ4"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  Support Center
                </Link>
              </li>
              <li>
                <Link
                  href="https://discord.gg/6ZsKWVggJY"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  Discord Community
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  Documentation
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  Status
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-4 relative inline-block">
              Legal
              <span className="absolute bottom-0 left-0 w-8 h-0.5 bg-gradient-to-r from-purple-500 to-transparent"></span>
            </h4>
            <ul className="space-y-2">
              <li>
                <Link
                  href="#"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  Refund Policy
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="text-slate-400 hover:text-white transition-colors hover:translate-x-1 inline-block"
                >
                  License Agreement
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-900 pt-8 text-center text-sm text-slate-500">
          <p>&copy; {new Date().getFullYear()} VEXOS. All rights reserved. The future of Roblox execution.</p>
        </div>
      </div>
    </footer>
  )
}

