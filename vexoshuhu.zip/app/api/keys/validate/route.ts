import { NextResponse } from "next/server"

// In a real application, this would be stored in a database
interface KeyData {
  key: string
  hwid: string
  expires: Date
  used: boolean
  createdAt: Date
  ip: string
}

// Simulated database of keys
const keysDatabase: Record<string, KeyData> = {}

export async function POST(request: Request) {
  try {
    const { key, hwid, executor_version } = await request.json()

    // Validate request
    if (!key) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing key parameter",
        },
        { status: 400 },
      )
    }

    // Find the key in our database
    const keyData = Object.values(keysDatabase).find((data) => data.key === key)

    if (!keyData) {
      return NextResponse.json(
        {
          success: false,
          valid: false,
          error: "Invalid key",
        },
        { status: 404 },
      )
    }

    // Check if key is expired
    const isExpired = new Date() > keyData.expires
    if (isExpired) {
      return NextResponse.json(
        {
          success: false,
          valid: false,
          error: "Key has expired",
          expires: keyData.expires,
        },
        { status: 400 },
      )
    }

    // Check if HWID matches (if provided)
    if (hwid && keyData.hwid !== hwid) {
      return NextResponse.json(
        {
          success: false,
          valid: false,
          error: "Hardware ID mismatch. This key is tied to a different device.",
        },
        { status: 400 },
      )
    }

    // Check executor version (optional)
    const minVersion = "1.0.0" // Minimum supported version
    if (executor_version && executor_version < minVersion) {
      return NextResponse.json(
        {
          success: false,
          valid: false,
          error: `Outdated executor version. Please update to version ${minVersion} or higher.`,
          minVersion,
        },
        { status: 400 },
      )
    }

    return NextResponse.json({
      success: true,
      valid: true,
      expires: keyData.expires,
      timeRemaining: Math.floor((keyData.expires.getTime() - Date.now()) / 1000), // in seconds
      hwid: keyData.hwid,
      features: {
        premium_scripts: true,
        auto_update: true,
        priority_execution: true,
      },
    })
  } catch (error) {
    console.error("Error validating key:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to validate key",
      },
      { status: 500 },
    )
  }
}

