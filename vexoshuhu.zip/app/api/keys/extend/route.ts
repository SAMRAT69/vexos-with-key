import { NextResponse } from "next/server"

// In a real application, this would be stored in a database
interface KeyData {
  key: string
  hwid: string
  expires: Date
  used: boolean
  createdAt: Date
  ip: string
  extensions: number
}

// Simulated database of keys
const keysDatabase: Record<string, KeyData> = {}

// Maximum number of extensions allowed per key
const MAX_EXTENSIONS = 3

export async function POST(request: Request) {
  try {
    const { key, hwid } = await request.json()

    // Validate request
    if (!key || !hwid) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing required parameters",
        },
        { status: 400 },
      )
    }

    // Find the key in our database
    const keyData = Object.values(keysDatabase).find((data) => data.key === key)

    if (!keyData) {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid key",
        },
        { status: 404 },
      )
    }

    // Check if HWID matches
    if (keyData.hwid !== hwid) {
      return NextResponse.json(
        {
          success: false,
          error: "Hardware ID mismatch. This key is tied to a different device.",
        },
        { status: 400 },
      )
    }

    // Check if key has reached maximum extensions
    if ((keyData.extensions || 0) >= MAX_EXTENSIONS) {
      return NextResponse.json(
        {
          success: false,
          error: `Maximum extensions reached (${MAX_EXTENSIONS})`,
        },
        { status: 400 },
      )
    }

    // Extend key by 24 hours
    const newExpiry = new Date(keyData.expires)
    if (newExpiry < new Date()) {
      // If already expired, extend from now
      newExpiry.setTime(Date.now() + 24 * 60 * 60 * 1000)
    } else {
      // If not expired, add 24 hours to current expiry
      newExpiry.setHours(newExpiry.getHours() + 24)
    }

    // Update key data
    keyData.expires = newExpiry
    keyData.extensions = (keyData.extensions || 0) + 1

    return NextResponse.json({
      success: true,
      key,
      expires: newExpiry,
      extensions: keyData.extensions,
      extensionsRemaining: MAX_EXTENSIONS - keyData.extensions,
      message: "Key extended successfully. Valid for an additional 24 hours.",
      timeRemaining: Math.floor((newExpiry.getTime() - Date.now()) / 1000), // in seconds
    })
  } catch (error) {
    console.error("Error extending key:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to extend key",
      },
      { status: 500 },
    )
  }
}

