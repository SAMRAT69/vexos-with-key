import { NextResponse } from "next/server"

// In a real application, this would be stored in a database
interface KeyData {
  key: string
  hwid: string
  expires: Date
  used: boolean
  createdAt: Date
  ip: string
}

// Simulated database of keys
const keysDatabase: Record<string, KeyData> = {
  "sample-key-id": {
    key: "VEXOS-ABC123-DEF456-GHI789",
    hwid: "ABCD-1234-EFGH-5678",
    expires: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours from now
    used: false,
    createdAt: new Date(),
    ip: "127.0.0.1",
  },
}

export async function POST(request: Request) {
  try {
    const { key, hwid } = await request.json()

    // Validate request
    if (!key || !hwid) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing required parameters",
        },
        { status: 400 },
      )
    }

    // Find the key in our database
    const keyData = Object.values(keysDatabase).find((data) => data.key === key)

    if (!keyData) {
      return NextResponse.json(
        {
          success: false,
          valid: false,
          error: "Invalid key",
        },
        { status: 400 },
      )
    }

    // Check if key is expired
    const isExpired = new Date() > keyData.expires
    if (isExpired) {
      return NextResponse.json(
        {
          success: false,
          valid: false,
          error: "Key has expired",
          expires: keyData.expires,
        },
        { status: 400 },
      )
    }

    // Check if key is already used
    if (keyData.used) {
      return NextResponse.json(
        {
          success: false,
          valid: false,
          error: "Key has already been used",
        },
        { status: 400 },
      )
    }

    // Check if HWID matches
    if (keyData.hwid !== hwid) {
      return NextResponse.json(
        {
          success: false,
          valid: false,
          error: "Hardware ID mismatch. This key is tied to a different device.",
        },
        { status: 400 },
      )
    }

    // Mark key as used (optional, depending on your requirements)
    // keyData.used = true;

    return NextResponse.json({
      success: true,
      valid: true,
      expires: keyData.expires,
      message: "Key verified successfully",
      timeRemaining: Math.floor((keyData.expires.getTime() - Date.now()) / 1000), // in seconds
    })
  } catch (error) {
    console.error("Error verifying key:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to verify key",
      },
      { status: 500 },
    )
  }
}

