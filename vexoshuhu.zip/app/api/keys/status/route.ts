import { NextResponse } from "next/server"

// In a real application, this would be stored in a database
interface KeyData {
  key: string
  hwid: string
  expires: Date
  used: boolean
  createdAt: Date
  ip: string
}

// Simulated database of keys
const keysDatabase: Record<string, KeyData> = {}

export async function POST(request: Request) {
  try {
    const { key } = await request.json()

    if (!key) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing key parameter",
        },
        { status: 400 },
      )
    }

    // Find the key in our database
    const keyData = Object.values(keysDatabase).find((data) => data.key === key)

    if (!keyData) {
      return NextResponse.json(
        {
          success: false,
          valid: false,
          error: "Key not found",
        },
        { status: 404 },
      )
    }

    // Check if key is expired
    const isExpired = new Date() > keyData.expires

    return NextResponse.json({
      success: true,
      valid: !isExpired && !keyData.used,
      expires: keyData.expires,
      used: keyData.used,
      created: keyData.createdAt,
      hwid: keyData.hwid,
      timeRemaining: isExpired ? 0 : Math.floor((keyData.expires.getTime() - Date.now()) / 1000), // in seconds
    })
  } catch (error) {
    console.error("Error checking key status:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to check key status",
      },
      { status: 500 },
    )
  }
}

