import { NextResponse } from "next/server"

// In a real application, this would be stored in a database
interface Script {
  id: string
  name: string
  description: string
  code: string
  game_id?: string
  category: string
  premium: boolean
  views: number
  downloads: number
  created_at: Date
  updated_at: Date
}

// Simulated database of scripts
const scriptsDatabase: Record<string, Script> = {
  "script-1": {
    id: "script-1",
    name: "Universal ESP",
    description: "See all players through walls with this universal ESP script",
    code: "-- Universal ESP Script\nprint('ESP Loaded')",
    category: "utility",
    premium: false,
    views: 1250,
    downloads: 850,
    created_at: new Date("2023-01-15"),
    updated_at: new Date("2023-06-20"),
  },
  "script-2": {
    id: "script-2",
    name: "Admin Commands",
    description: "Get admin commands in any game",
    code: "-- Admin Commands Script\nprint('Admin Commands Loaded')",
    category: "admin",
    premium: true,
    views: 3500,
    downloads: 2100,
    created_at: new Date("2023-02-10"),
    updated_at: new Date("2023-07-15"),
  },
  "script-3": {
    id: "script-3",
    name: "Infinite Jump",
    description: "Jump infinitely in any game",
    code: "-- Infinite Jump Script\nprint('Infinite Jump Loaded')",
    game_id: "1234567890",
    category: "movement",
    premium: false,
    views: 950,
    downloads: 620,
    created_at: new Date("2023-03-05"),
    updated_at: new Date("2023-05-10"),
  },
}

export async function POST(request: Request) {
  try {
    const { key, hwid, script_id } = await request.json()

    // Validate request
    if (!script_id) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing script ID",
        },
        { status: 400 },
      )
    }

    // Validate key and HWID (simplified for example)
    // In a real implementation, you would call your key verification service
    const keyValid = key && key.startsWith("VEXOS-")
    const isPremium = keyValid // Simplified - in reality, check if key grants premium access

    // Find the script
    const script = scriptsDatabase[script_id]
    if (!script) {
      return NextResponse.json(
        {
          success: false,
          error: "Script not found",
        },
        { status: 404 },
      )
    }

    // Check if user has access to premium scripts
    if (script.premium && !isPremium) {
      return NextResponse.json(
        {
          success: false,
          error: "Premium access required for this script",
        },
        { status: 403 },
      )
    }

    // Increment download count (in a real app, you'd update the database)
    script.downloads += 1

    // Return the script with code
    return NextResponse.json({
      success: true,
      script: {
        ...script,
        has_access: true,
      },
    })
  } catch (error) {
    console.error("Error fetching script:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch script",
      },
      { status: 500 },
    )
  }
}

