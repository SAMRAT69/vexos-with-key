import { NextResponse } from "next/server"

// In a real application, this would be stored in a database
interface Script {
  id: string
  name: string
  description: string
  code: string
  game_id?: string
  category: string
  premium: boolean
  views: number
  downloads: number
  created_at: Date
  updated_at: Date
}

// Simulated database of scripts
const scriptsDatabase: Record<string, Script> = {
  "script-1": {
    id: "script-1",
    name: "Universal ESP",
    description: "See all players through walls with this universal ESP script",
    code: "-- Universal ESP Script\nprint('ESP Loaded')",
    category: "utility",
    premium: false,
    views: 1250,
    downloads: 850,
    created_at: new Date("2023-01-15"),
    updated_at: new Date("2023-06-20"),
  },
  "script-2": {
    id: "script-2",
    name: "Admin Commands",
    description: "Get admin commands in any game",
    code: "-- Admin Commands Script\nprint('Admin Commands Loaded')",
    category: "admin",
    premium: true,
    views: 3500,
    downloads: 2100,
    created_at: new Date("2023-02-10"),
    updated_at: new Date("2023-07-15"),
  },
  "script-3": {
    id: "script-3",
    name: "Infinite Jump",
    description: "Jump infinitely in any game",
    code: "-- Infinite Jump Script\nprint('Infinite Jump Loaded')",
    game_id: "1234567890",
    category: "movement",
    premium: false,
    views: 950,
    downloads: 620,
    created_at: new Date("2023-03-05"),
    updated_at: new Date("2023-05-10"),
  },
}

export async function POST(request: Request) {
  try {
    const { key, hwid, game_id, category, premium_only } = await request.json()

    // Validate key and HWID (simplified for example)
    // In a real implementation, you would call your key verification service
    const keyValid = key && key.startsWith("VEXOS-")
    const isPremium = keyValid // Simplified - in reality, check if key grants premium access

    // Filter scripts based on parameters
    let scripts = Object.values(scriptsDatabase)

    // Filter by game ID if provided
    if (game_id) {
      scripts = scripts.filter((script) => !script.game_id || script.game_id === game_id)
    }

    // Filter by category if provided
    if (category) {
      scripts = scripts.filter((script) => script.category === category)
    }

    // Filter premium scripts
    if (premium_only === true) {
      if (!isPremium) {
        return NextResponse.json(
          {
            success: false,
            error: "Premium access required for premium scripts",
          },
          { status: 403 },
        )
      }
      scripts = scripts.filter((script) => script.premium)
    } else if (!isPremium) {
      // Non-premium users can only see non-premium scripts
      scripts = scripts.filter((script) => !script.premium)
    }

    // Return script list without the actual code
    const scriptList = scripts.map(({ code, ...script }) => ({
      ...script,
      has_access: !script.premium || isPremium,
    }))

    return NextResponse.json({
      success: true,
      scripts: scriptList,
      total: scriptList.length,
      premium_access: isPremium,
    })
  } catch (error) {
    console.error("Error fetching scripts:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch scripts",
      },
      { status: 500 },
    )
  }
}

