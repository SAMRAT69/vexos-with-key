import { NextResponse } from "next/server"
import { v4 as uuidv4 } from "uuid"

// In a real application, this would be stored in a database
interface ExecutionRecord {
  id: string
  key: string
  hwid: string
  script: string
  game_id?: string
  status: "pending" | "completed" | "failed"
  error?: string
  created_at: Date
  completed_at?: Date
}

// Simulated database of execution records
const executionsDatabase: Record<string, ExecutionRecord> = {}

export async function POST(request: Request) {
  try {
    const { key, hwid, script, game_id } = await request.json()

    // Validate request
    if (!key || !hwid || !script) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing required parameters",
        },
        { status: 400 },
      )
    }

    // Validate key and HWID (simplified for example)
    // In a real implementation, you would call your key verification service
    const keyValid = key && key.startsWith("VEXOS-")
    if (!keyValid) {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid key",
        },
        { status: 403 },
      )
    }

    // Create execution record
    const executionId = uuidv4()
    const now = new Date()

    executionsDatabase[executionId] = {
      id: executionId,
      key,
      hwid,
      script,
      game_id,
      status: "pending",
      created_at: now,
    }

    // Simulate script execution (in a real app, this would be more complex)
    setTimeout(() => {
      const execution = executionsDatabase[executionId]
      if (execution) {
        execution.status = "completed"
        execution.completed_at = new Date()
      }
    }, 1000)

    return NextResponse.json({
      success: true,
      execution_id: executionId,
      status: "pending",
      message: "Script execution initiated",
    })
  } catch (error) {
    console.error("Error executing script:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to execute script",
      },
      { status: 500 },
    )
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const executionId = searchParams.get("id")

    if (!executionId) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing execution ID",
        },
        { status: 400 },
      )
    }

    const execution = executionsDatabase[executionId]
    if (!execution) {
      return NextResponse.json(
        {
          success: false,
          error: "Execution record not found",
        },
        { status: 404 },
      )
    }

    return NextResponse.json({
      success: true,
      execution: {
        id: execution.id,
        status: execution.status,
        created_at: execution.created_at,
        completed_at: execution.completed_at,
        error: execution.error,
      },
    })
  } catch (error) {
    console.error("Error checking execution status:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to check execution status",
      },
      { status: 500 },
    )
  }
}

