import { NextResponse } from "next/server"

// Simulated database of keys
const keys: { [key: string]: { hwid: string; expires: Date; used: boolean } } = {}

export async function POST(request: Request) {
  try {
    const { hwid, steps_completed } = await request.json()

    // Validate request
    if (!hwid || !steps_completed) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    // Verify all steps are completed
    if (steps_completed.length < 4) {
      return NextResponse.json({ error: "All steps must be completed to generate a key" }, { status: 400 })
    }

    // Generate a unique key
    const keyPart1 = Math.random().toString(36).substring(2, 8).toUpperCase()
    const keyPart2 = Math.random().toString(36).substring(2, 8).toUpperCase()
    const keyPart3 = Math.random().toString(36).substring(2, 8).toUpperCase()

    const key = `VEXOS-${keyPart1}-${keyPart2}-${keyPart3}`

    // Set expiration date (24 hours from now)
    const expires = new Date()
    expires.setHours(expires.getHours() + 24)

    // Store key in our "database"
    keys[key] = {
      hwid,
      expires,
      used: false,
    }

    return NextResponse.json({
      success: true,
      key,
      expires,
      message: "Key generated successfully. Valid for 24 hours.",
    })
  } catch (error) {
    console.error("Error generating key:", error)
    return NextResponse.json({ error: "Failed to generate key" }, { status: 500 })
  }
}

