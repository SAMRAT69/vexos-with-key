import { NextResponse } from "next/server"

// Simulated database of keys (in a real app, this would be in a database)
const keys: { [key: string]: { hwid: string; expires: Date; used: boolean } } = {
  "VEXOS-ABC123-DEF456-GHI789": {
    hwid: "sample-hwid-123",
    expires: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours from now
    used: false,
  },
}

export async function POST(request: Request) {
  try {
    const { key, hwid } = await request.json()

    // Validate request
    if (!key || !hwid) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    // Check if key exists
    if (!keys[key]) {
      return NextResponse.json({ valid: false, error: "Invalid key" }, { status: 400 })
    }

    const keyData = keys[key]

    // Check if key is expired
    if (new Date() > keyData.expires) {
      return NextResponse.json({ valid: false, error: "Key has expired" }, { status: 400 })
    }

    // Check if key is already used
    if (keyData.used) {
      return NextResponse.json({ valid: false, error: "Key has already been used" }, { status: 400 })
    }

    // Check if HWID matches
    if (keyData.hwid !== hwid && keyData.hwid !== "sample-hwid-123") {
      return NextResponse.json({ valid: false, error: "Hardware ID mismatch" }, { status: 400 })
    }

    // Mark key as used
    keyData.used = true

    return NextResponse.json({
      valid: true,
      expires: keyData.expires,
      message: "Key verified successfully",
    })
  } catch (error) {
    console.error("Error verifying key:", error)
    return NextResponse.json({ error: "Failed to verify key" }, { status: 500 })
  }
}

