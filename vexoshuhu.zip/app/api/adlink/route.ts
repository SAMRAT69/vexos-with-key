import { NextResponse } from "next/server"

// Simulated ad link destinations
const adDestinations = [
  "https://example.com/ad1?ref=vexos",
  "https://example.com/ad2?ref=vexos",
  "https://example.com/ad3?ref=vexos",
  "https://example.com/ad4?ref=vexos",
]

// Simulated tracking data
const adTracking: { [id: string]: { visits: number; completed: boolean; timestamp: Date } } = {}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const adId = searchParams.get("id")
  const userId = searchParams.get("user")

  if (!adId || !userId) {
    return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
  }

  // Generate a unique tracking ID
  const trackingId = `${userId}-${adId}-${Date.now()}`

  // Store tracking data
  adTracking[trackingId] = {
    visits: 1,
    completed: false,
    timestamp: new Date(),
  }

  // Get destination URL (in a real app, you'd have more sophisticated logic)
  const destinationIndex = Number.parseInt(adId) % adDestinations.length
  const destination = adDestinations[destinationIndex]

  // Add tracking parameters
  const finalDestination = `${destination}&tracking=${trackingId}`

  return NextResponse.json({
    success: true,
    redirect: finalDestination,
    trackingId,
  })
}

export async function POST(request: Request) {
  try {
    const { trackingId, action } = await request.json()

    if (!trackingId || !action) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    // Check if tracking ID exists
    if (!adTracking[trackingId]) {
      return NextResponse.json({ error: "Invalid tracking ID" }, { status: 400 })
    }

    // Update tracking data based on action
    if (action === "complete") {
      adTracking[trackingId].completed = true
    } else if (action === "visit") {
      adTracking[trackingId].visits += 1
    }

    return NextResponse.json({
      success: true,
      tracking: adTracking[trackingId],
    })
  } catch (error) {
    console.error("Error updating ad tracking:", error)
    return NextResponse.json({ error: "Failed to update tracking" }, { status: 500 })
  }
}

