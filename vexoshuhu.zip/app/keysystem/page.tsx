"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, XCircle, Copy, ExternalLink, Clock, RefreshCw, Key, Shield, AlertTriangle } from "lucide-react"
import Link from "next/link"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function KeySystemPage() {
  const [currentStep, setCurrentStep] = useState("adlink")
  const [isLoading, setIsLoading] = useState(false)
  const [generatedKey, setGeneratedKey] = useState("")
  const [hwid, setHWID] = useState("")
  const [error, setError] = useState("")
  const [progress, setProgress] = useState(0)
  const [adlinkTimeRemaining, setAdlinkTimeRemaining] = useState(30)
  const [adlinkTimerActive, setAdlinkTimerActive] = useState(false)
  const [discordVerified, setDiscordVerified] = useState(false)
  const [nextGenerationTime, setNextGenerationTime] = useState<Date | null>(null)
  const [steps, setSteps] = useState({
    adlink: { completed: false, timestamp: null },
    discord: { completed: false, timestamp: null },
    verify: { completed: false, timestamp: null },
  })
  const [isInitialized, setIsInitialized] = useState(false)

  // Get HWID from URL or localStorage on component mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const hwidParam = params.get("hwid")

    if (hwidParam) {
      setHWID(hwidParam)
      localStorage.setItem("vexos_hwid", hwidParam)
    } else {
      // If no HWID in URL, try to get from localStorage or generate a new one
      const storedHWID = localStorage.getItem("vexos_hwid")
      if (storedHWID) {
        setHWID(storedHWID)

        // Update URL with the HWID parameter without reloading the page
        const url = new URL(window.location.href)
        url.searchParams.set("hwid", storedHWID)
        window.history.pushState({}, "", url)
      } else {
        generateHWID()
      }
    }
  }, [])

  // Load saved progress on component mount
  useEffect(() => {
    if (hwid && !isInitialized) {
      loadProgress()
      setIsInitialized(true)
    }
  }, [hwid, isInitialized])

  // Adlink timer
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null

    if (adlinkTimerActive && adlinkTimeRemaining > 0) {
      timer = setInterval(() => {
        setAdlinkTimeRemaining((prev) => prev - 1)
      }, 1000)
    } else if (adlinkTimeRemaining === 0 && adlinkTimerActive) {
      setAdlinkTimerActive(false)
      completeStep("adlink")
    }

    return () => {
      if (timer) clearInterval(timer)
    }
  }, [adlinkTimerActive, adlinkTimeRemaining])

  const generateHWID = async () => {
    try {
      const response = await fetch("/v1/hwid/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({}),
      })

      const data = await response.json()

      if (response.ok) {
        setHWID(data.hwid)
        localStorage.setItem("vexos_hwid", data.hwid)

        // Update URL with the HWID parameter without reloading the page
        const url = new URL(window.location.href)
        url.searchParams.set("hwid", data.hwid)
        window.history.pushState({}, "", url)
      } else {
        setError(data.error || "Failed to generate HWID")
      }
    } catch (err: any) {
      setError(err.message || "An error occurred")
    }
  }

  const loadProgress = async () => {
    if (!hwid) return

    setIsLoading(true)
    setError("")

    try {
      // First check for existing key for this HWID
      const storedKey = localStorage.getItem(`vexos_key_${hwid}`)
      const storedKeyExpiry = localStorage.getItem(`vexos_key_expiry_${hwid}`)

      if (storedKey && storedKeyExpiry) {
        const expiryDate = new Date(storedKeyExpiry)
        if (expiryDate > new Date()) {
          setGeneratedKey(storedKey)
          setIsLoading(false)
          return
        } else {
          // Clear expired key
          localStorage.removeItem(`vexos_key_${hwid}`)
          localStorage.removeItem(`vexos_key_expiry_${hwid}`)
        }
      }

      // Check for cooldown for this HWID
      const cooldownTime = localStorage.getItem(`vexos_cooldown_${hwid}`)
      if (cooldownTime) {
        const cooldownDate = new Date(cooldownTime)
        if (cooldownDate > new Date()) {
          setNextGenerationTime(cooldownDate)
        } else {
          localStorage.removeItem(`vexos_cooldown_${hwid}`)
        }
      }

      // Load progress from server
      const response = await fetch(`/v1/keys/process?hwid=${hwid}`)
      const data = await response.json()

      if (response.ok) {
        setProgress(data.progress)
        setSteps(data.steps)

        // Set current step to next incomplete step
        if (data.nextStep) {
          setCurrentStep(data.nextStep)
        }

        // If all steps are completed, try to generate key
        if (data.completed) {
          generateKey()
        }
      }
    } catch (err: any) {
      console.error("Error loading progress:", err)
      setError("Failed to load your progress. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const startAdlinkTimer = async () => {
    setIsLoading(true)
    setError("")

    try {
      const response = await fetch("/v1/adlink/verify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ hwid, action: "start" }),
      })

      const data = await response.json()

      if (response.ok) {
        setAdlinkTimerActive(true)
        setAdlinkTimeRemaining(data.requiredTime)

        // Open adlink in new tab
        window.open("https://example.com/adlink", "_blank")
      } else {
        setError(data.error || "Failed to start adlink verification")
      }
    } catch (err: any) {
      setError(err.message || "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const verifyDiscord = async () => {
    setIsLoading(true)
    setError("")

    try {
      // First get the Discord link
      const linkResponse = await fetch("/v1/discord/verify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ hwid, action: "getlink" }),
      })

      const linkData = await linkResponse.json()

      if (linkResponse.ok) {
        // Open Discord invite in new tab
        window.open(linkData.discordLink, "_blank")

        // Simulate verification after a delay
        setTimeout(async () => {
          const verifyResponse = await fetch("/v1/discord/verify", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ hwid, action: "verify" }),
          })

          const verifyData = await verifyResponse.json()

          if (verifyResponse.ok && verifyData.verified) {
            setDiscordVerified(true)
            completeStep("discord")
          } else {
            setError("Failed to verify Discord join")
          }

          setIsLoading(false)
        }, 3000)
      } else {
        setError(linkData.error || "Failed to get Discord link")
        setIsLoading(false)
      }
    } catch (err: any) {
      setError(err.message || "An error occurred")
      setIsLoading(false)
    }
  }

  const completeVerification = async () => {
    setIsLoading(true)
    setError("")

    try {
      // Simulate verification
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Complete the verification step
      await completeStep("verify")

      // Generate key
      await generateKey()
    } catch (err: any) {
      setError(err.message || "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const completeStep = async (step: string) => {
    try {
      const response = await fetch("/v1/keys/process", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ hwid, step, action: "complete" }),
      })

      const data = await response.json()

      if (response.ok) {
        setProgress(data.progress)
        setSteps(data.steps)

        // Move to next step if available
        if (data.nextStep) {
          setCurrentStep(data.nextStep)
        } else if (data.completed) {
          // All steps completed
          generateKey()
        }
      } else {
        setError(data.error || "Failed to complete step")
      }
    } catch (err: any) {
      setError(err.message || "An error occurred")
    }
  }

  const generateKey = async () => {
    setIsLoading(true)
    setError("")

    try {
      const response = await fetch("/v1/keys/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ hwid }),
      })

      const data = await response.json()

      if (response.ok) {
        setGeneratedKey(data.key)

        // Store key and expiry in localStorage with HWID-specific keys
        localStorage.setItem(`vexos_key_${hwid}`, data.key)
        localStorage.setItem(`vexos_key_expiry_${hwid}`, data.expires)

        if (data.nextGenerationTime) {
          setNextGenerationTime(new Date(data.nextGenerationTime))
          localStorage.setItem(`vexos_cooldown_${hwid}`, data.nextGenerationTime)
        }
      } else {
        setError(data.error || "Failed to generate key")

        // Check if there's a next generation time in the error response
        if (data.nextGenerationTime) {
          setNextGenerationTime(new Date(data.nextGenerationTime))
          localStorage.setItem(`vexos_cooldown_${hwid}`, data.nextGenerationTime)
        }
      }
    } catch (err: any) {
      setError(err.message || "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedKey)
    alert("Key copied to clipboard!")
  }

  const resetKeySystem = async () => {
    setIsLoading(true)
    setError("")

    try {
      // Reset progress on server
      const response = await fetch("/v1/keys/process", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ hwid, action: "reset" }),
      })

      if (response.ok) {
        // Reset local state
        setCurrentStep("adlink")
        setGeneratedKey("")
        setProgress(0)
        setSteps({
          adlink: { completed: false, timestamp: null },
          discord: { completed: false, timestamp: null },
          verify: { completed: false, timestamp: null },
        })
        setAdlinkTimeRemaining(30)
        setAdlinkTimerActive(false)
        setDiscordVerified(false)
        setNextGenerationTime(null)

        // Clear stored key for this specific HWID
        localStorage.removeItem(`vexos_key_${hwid}`)
        localStorage.removeItem(`vexos_key_expiry_${hwid}`)
        localStorage.removeItem(`vexos_cooldown_${hwid}`)
      } else {
        const data = await response.json()
        setError(data.error || "Failed to reset progress")
      }
    } catch (err: any) {
      setError(err.message || "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const formatTimeRemaining = () => {
    if (!nextGenerationTime) return ""

    const now = new Date()
    const diff = nextGenerationTime.getTime() - now.getTime()

    if (diff <= 0) return "Now"

    const hours = Math.floor(diff / (1000 * 60 * 60))
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

    return `${hours}h ${minutes}m`
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-slate-900 to-slate-950">
      <Navbar />

      <main className="flex-1 pt-24">
        <div className="container px-4 mx-auto py-12">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-purple-500 inline-block">
                VEXOS Key System
              </h1>
              <p className="text-slate-400 max-w-2xl mx-auto">
                Complete the steps below to generate your unique key and unlock the full power of VEXOS Executor. Your
                key will be valid for 24 hours and is tied to your hardware ID.
              </p>
            </div>

            {error && (
              <Alert variant="destructive" className="mb-6">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 md:p-8 mb-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold">Key Generation Progress</h3>
                <span className="text-sm text-slate-400">{Math.round(progress)}% Complete</span>
              </div>

              <Progress value={progress} className="h-2 mb-8" />

              <div className="flex items-center gap-3 mb-6 p-4 bg-slate-800/30 rounded-lg">
                <Shield className="h-5 w-5 text-purple-500" />
                <div>
                  <p className="text-sm font-medium">Your Hardware ID (HWID)</p>
                  <p className="text-xs text-slate-400 font-mono">{hwid}</p>
                </div>
              </div>

              {nextGenerationTime && nextGenerationTime > new Date() && !generatedKey && (
                <div className="mb-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg flex items-center gap-3">
                  <Clock className="h-5 w-5 text-amber-500" />
                  <div>
                    <p className="text-sm font-medium text-amber-200">Key Generation Cooldown</p>
                    <p className="text-xs text-amber-200/70">You can generate a new key in {formatTimeRemaining()}</p>
                  </div>
                </div>
              )}

              {isLoading && !generatedKey && (
                <div className="flex justify-center items-center py-8">
                  <div className="flex flex-col items-center">
                    <RefreshCw className="h-8 w-8 text-purple-500 animate-spin mb-4" />
                    <p className="text-slate-400">Loading your progress...</p>
                  </div>
                </div>
              )}

              {!isLoading && generatedKey ? (
                <div className="text-center py-8">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-purple-500/20 text-purple-500 mb-4">
                    <Key size={32} />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Your Key Has Been Generated!</h3>
                  <p className="text-slate-400 mb-6">Use this key to activate your VEXOS Executor</p>

                  <div className="flex items-center justify-center mb-8">
                    <div className="bg-slate-950 rounded-lg px-6 py-3 font-mono text-purple-400 border border-purple-500/30 flex items-center">
                      {generatedKey}
                      <button
                        onClick={copyToClipboard}
                        className="ml-3 text-slate-400 hover:text-white transition-colors"
                      >
                        <Copy size={16} />
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                    <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                      <Link href="/download">Download Executor</Link>
                    </Button>
                    <Button variant="outline" onClick={resetKeySystem}>
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Generate New Key
                    </Button>
                  </div>
                </div>
              ) : (
                !isLoading && (
                  <div className="space-y-6">
                    {/* Adlink Step */}
                    <div
                      className={`border rounded-lg p-4 transition-all ${
                        currentStep === "adlink"
                          ? "border-purple-500 bg-purple-500/10"
                          : steps.adlink.completed
                            ? "border-green-500/30 bg-green-500/5"
                            : "border-slate-800 bg-slate-900/30"
                      }`}
                    >
                      <div className="flex items-start">
                        <div
                          className={`flex items-center justify-center w-8 h-8 rounded-full mr-3 shrink-0 ${
                            steps.adlink.completed
                              ? "bg-green-500/20 text-green-500"
                              : currentStep === "adlink"
                                ? "bg-purple-500/20 text-purple-500"
                                : "bg-slate-800 text-slate-400"
                          }`}
                        >
                          {steps.adlink.completed ? <CheckCircle size={16} /> : <span>1</span>}
                        </div>

                        <div className="flex-1">
                          <h4 className="font-medium mb-1">Visit Our Ad Link</h4>
                          <p className="text-sm text-slate-400 mb-4">
                            Click the button below to visit our ad link. Stay on the page for at least 30 seconds.
                          </p>

                          {currentStep === "adlink" && !steps.adlink.completed && (
                            <>
                              {adlinkTimerActive ? (
                                <div className="mb-4">
                                  <Progress value={((30 - adlinkTimeRemaining) / 30) * 100} className="h-2 mb-2" />
                                  <p className="text-sm text-slate-400">Please wait {adlinkTimeRemaining} seconds...</p>
                                </div>
                              ) : (
                                <Button
                                  onClick={startAdlinkTimer}
                                  disabled={isLoading}
                                  className="w-full sm:w-auto bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                                >
                                  {isLoading ? (
                                    <>
                                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                                      Processing...
                                    </>
                                  ) : (
                                    <>
                                      <ExternalLink className="mr-2 h-4 w-4" />
                                      Visit Ad Link
                                    </>
                                  )}
                                </Button>
                              )}
                            </>
                          )}

                          {steps.adlink.completed && (
                            <span className="inline-flex items-center text-sm text-green-500">
                              <CheckCircle className="mr-1 h-4 w-4" />
                              Completed
                              {steps.adlink.timestamp && (
                                <span className="ml-2 text-xs text-green-500/70">
                                  {new Date(steps.adlink.timestamp).toLocaleString()}
                                </span>
                              )}
                            </span>
                          )}

                          {!currentStep.includes("adlink") && !steps.adlink.completed && (
                            <span className="inline-flex items-center text-sm text-slate-500">
                              <Clock className="mr-1 h-4 w-4" />
                              Waiting
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Discord Step */}
                    <div
                      className={`border rounded-lg p-4 transition-all ${
                        currentStep === "discord"
                          ? "border-purple-500 bg-purple-500/10"
                          : steps.discord.completed
                            ? "border-green-500/30 bg-green-500/5"
                            : "border-slate-800 bg-slate-900/30"
                      }`}
                    >
                      <div className="flex items-start">
                        <div
                          className={`flex items-center justify-center w-8 h-8 rounded-full mr-3 shrink-0 ${
                            steps.discord.completed
                              ? "bg-green-500/20 text-green-500"
                              : currentStep === "discord"
                                ? "bg-purple-500/20 text-purple-500"
                                : "bg-slate-800 text-slate-400"
                          }`}
                        >
                          {steps.discord.completed ? <CheckCircle size={16} /> : <span>2</span>}
                        </div>

                        <div className="flex-1">
                          <h4 className="font-medium mb-1">Join Our Discord Server</h4>
                          <p className="text-sm text-slate-400 mb-4">
                            Join our Discord community to get support and updates about VEXOS.
                          </p>

                          {currentStep === "discord" && !steps.discord.completed && (
                            <Button
                              onClick={verifyDiscord}
                              disabled={isLoading}
                              className="w-full sm:w-auto bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                            >
                              {isLoading ? (
                                <>
                                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                                  Verifying...
                                </>
                              ) : (
                                <>
                                  <ExternalLink className="mr-2 h-4 w-4" />
                                  Join Discord
                                </>
                              )}
                            </Button>
                          )}

                          {steps.discord.completed && (
                            <span className="inline-flex items-center text-sm text-green-500">
                              <CheckCircle className="mr-1 h-4 w-4" />
                              Completed
                              {steps.discord.timestamp && (
                                <span className="ml-2 text-xs text-green-500/70">
                                  {new Date(steps.discord.timestamp).toLocaleString()}
                                </span>
                              )}
                            </span>
                          )}

                          {!currentStep.includes("discord") && !steps.discord.completed && (
                            <span className="inline-flex items-center text-sm text-slate-500">
                              <Clock className="mr-1 h-4 w-4" />
                              Waiting
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Verification Step */}
                    <div
                      className={`border rounded-lg p-4 transition-all ${
                        currentStep === "verify"
                          ? "border-purple-500 bg-purple-500/10"
                          : steps.verify.completed
                            ? "border-green-500/30 bg-green-500/5"
                            : "border-slate-800 bg-slate-900/30"
                      }`}
                    >
                      <div className="flex items-start">
                        <div
                          className={`flex items-center justify-center w-8 h-8 rounded-full mr-3 shrink-0 ${
                            steps.verify.completed
                              ? "bg-green-500/20 text-green-500"
                              : currentStep === "verify"
                                ? "bg-purple-500/20 text-purple-500"
                                : "bg-slate-800 text-slate-400"
                          }`}
                        >
                          {steps.verify.completed ? <CheckCircle size={16} /> : <span>3</span>}
                        </div>

                        <div className="flex-1">
                          <h4 className="font-medium mb-1">Verify Your Identity</h4>
                          <p className="text-sm text-slate-400 mb-4">
                            Complete a quick verification to prove you're human and generate your key.
                          </p>

                          {currentStep === "verify" && !steps.verify.completed && (
                            <Button
                              onClick={completeVerification}
                              disabled={isLoading}
                              className="w-full sm:w-auto bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                            >
                              {isLoading ? (
                                <>
                                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                                  Verifying...
                                </>
                              ) : (
                                <>
                                  <ExternalLink className="mr-2 h-4 w-4" />
                                  Verify & Generate Key
                                </>
                              )}
                            </Button>
                          )}

                          {steps.verify.completed && (
                            <span className="inline-flex items-center text-sm text-green-500">
                              <CheckCircle className="mr-1 h-4 w-4" />
                              Completed
                              {steps.verify.timestamp && (
                                <span className="ml-2 text-xs text-green-500/70">
                                  {new Date(steps.verify.timestamp).toLocaleString()}
                                </span>
                              )}
                            </span>
                          )}

                          {!currentStep.includes("verify") && !steps.verify.completed && (
                            <span className="inline-flex items-center text-sm text-slate-500">
                              <Clock className="mr-1 h-4 w-4" />
                              Waiting
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )
              )}
            </div>

            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 md:p-8">
              <h3 className="text-xl font-bold mb-4">Key System Information</h3>
              <ul className="space-y-3 text-slate-400">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0 mt-0.5" />
                  <span>Each key is valid for 24 hours after generation</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0 mt-0.5" />
                  <span>Keys are tied to your hardware ID for security</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0 mt-0.5" />
                  <span>Premium users can generate keys without ads</span>
                </li>
                <li className="flex items-start">
                  <XCircle className="h-5 w-5 text-red-500 mr-2 shrink-0 mt-0.5" />
                  <span>Do not share your key with others - this will result in a ban</span>
                </li>
                <li className="flex items-start">
                  <XCircle className="h-5 w-5 text-red-500 mr-2 shrink-0 mt-0.5" />
                  <span>Using VPNs or proxies during key generation is not allowed</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

