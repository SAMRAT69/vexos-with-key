"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, AlertTriangle, Key, Lock, Shield, Sparkles, Clock, Copy, RefreshCw } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function PremiumKeyAddPage() {
  const [key, setKey] = useState("")
  const [duration, setDuration] = useState("1week")
  const [password, setPassword] = useState("")
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [addedKey, setAddedKey] = useState<any>(null)
  const [isGeneratingKey, setIsGeneratingKey] = useState(false)
  const [showCopiedMessage, setShowCopiedMessage] = useState(false)
  const [animateSuccess, setAnimateSuccess] = useState(false)

  // Generate a random premium key
  const generateRandomKey = () => {
    setIsGeneratingKey(true)

    // Simulate loading
    setTimeout(() => {
      const keyPart1 = "PREMIUM"
      const keyPart2 = Math.random().toString(36).substring(2, 8).toUpperCase()
      const keyPart3 = Math.random().toString(36).substring(2, 8).toUpperCase()

      setKey(`VEXOS-${keyPart1}-${keyPart2}-${keyPart3}`)
      setIsGeneratingKey(false)
    }, 800)
  }

  const handleAddKey = () => {
    // Validate input
    if (!key) {
      setError("Please enter a key")
      return
    }

    // Show password modal
    setShowPasswordModal(true)
  }

  const handleConfirmAdd = async () => {
    setIsLoading(true)
    setError("")
    setSuccess("")

    try {
      const response = await fetch("/v1/keys/premium/add", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          key,
          duration,
          password,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setSuccess("Premium key added successfully!")
        setAddedKey(data)
        setShowPasswordModal(false)
        setAnimateSuccess(true)

        // Reset animation after 2 seconds
        setTimeout(() => {
          setAnimateSuccess(false)
        }, 2000)

        // Reset form
        setKey("")
        setDuration("1week")
        setPassword("")
      } else {
        setError(data.error || "Failed to add premium key")
      }
    } catch (err: any) {
      setError(err.message || "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const handleCancelAdd = () => {
    setShowPasswordModal(false)
    setPassword("")
  }

  const copyToClipboard = () => {
    if (!addedKey) return

    navigator.clipboard.writeText(addedKey.key)
    setShowCopiedMessage(true)

    setTimeout(() => {
      setShowCopiedMessage(false)
    }, 2000)
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-slate-900 via-slate-900 to-black">
      <Navbar />

      {/* Animated background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(124,58,237,0.15),transparent_50%)]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(244,63,94,0.15),transparent_50%)]"></div>
        <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500/10 rounded-full filter blur-3xl opacity-30 animate-blob"></div>
        <div className="absolute top-40 right-10 w-72 h-72 bg-pink-500/10 rounded-full filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-20 left-1/2 w-72 h-72 bg-blue-500/10 rounded-full filter blur-3xl opacity-30 animate-blob animation-delay-4000"></div>
      </div>

      <main className="flex-1 pt-24 relative z-10">
        <div className="container px-4 mx-auto py-12">
          <div className="max-w-lg mx-auto">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 mb-4 shadow-lg shadow-purple-500/20">
                <Key className="h-8 w-8 text-white" />
              </div>
              <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white via-purple-400 to-pink-500 inline-block">
                Premium Key Management
              </h1>
              <p className="text-slate-400 max-w-md mx-auto">
                Create and manage premium keys for VEXOS Executor with extended durations and special privileges
              </p>
            </div>

            {error && (
              <Alert variant="destructive" className="mb-6 animate-shake">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className={`mb-6 border-green-500 bg-green-500/10 ${animateSuccess ? "animate-pulse" : ""}`}>
                <CheckCircle className="h-4 w-4 text-green-500" />
                <AlertDescription className="text-green-500">{success}</AlertDescription>
              </Alert>
            )}

            {addedKey && (
              <Card className="mb-8 border-purple-500/30 bg-gradient-to-br from-purple-900/20 to-pink-900/20 backdrop-blur-sm overflow-hidden relative">
                <div className="absolute inset-0 bg-grid-white/5 mask-linear-gradient-to-b from-transparent to-black"></div>

                <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent"></div>
                <div className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-pink-500 to-transparent"></div>
                <div className="absolute left-0 inset-y-0 w-px bg-gradient-to-b from-transparent via-purple-500 to-transparent"></div>
                <div className="absolute right-0 inset-y-0 w-px bg-gradient-to-b from-transparent via-pink-500 to-transparent"></div>

                <CardHeader className="relative z-10">
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-xl">
                      <Sparkles className="h-5 w-5 text-purple-400" />
                      Premium Key Created
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-xs px-2 py-1 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/30 ${addedKey.duration === "lifetime" ? "animate-pulse" : ""}`}
                      >
                        {addedKey.duration === "lifetime" ? "Lifetime" : addedKey.duration}
                      </span>
                    </div>
                  </div>
                  <CardDescription>This key grants premium access to VEXOS Executor</CardDescription>
                </CardHeader>

                <CardContent className="relative z-10">
                  <div className="bg-slate-950/80 rounded-lg p-4 border border-purple-500/20 mb-4 relative overflow-hidden group">
                    <div className="absolute inset-0 bg-gradient-to-r from-purple-500/5 to-pink-500/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-purple-400 text-sm md:text-base break-all">{addedKey.key}</span>
                      <button
                        onClick={copyToClipboard}
                        className="ml-2 p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
                      >
                        <Copy className="h-4 w-4" />
                      </button>
                    </div>
                    {showCopiedMessage && (
                      <div className="absolute bottom-1 right-1 text-xs text-green-500 bg-green-500/10 px-2 py-0.5 rounded animate-fade-in-out">
                        Copied!
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-800">
                      <div className="text-slate-400 mb-1">Type</div>
                      <div className="font-medium text-purple-400">Premium</div>
                    </div>
                    <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-800">
                      <div className="text-slate-400 mb-1">Duration</div>
                      <div className="font-medium text-purple-400">{addedKey.duration}</div>
                    </div>
                    <div className="bg-slate-900/50 rounded-lg p-3 border border-slate-800 col-span-2">
                      <div className="text-slate-400 mb-1">Expires</div>
                      <div className="font-medium text-purple-400 flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        {addedKey.duration === "lifetime"
                          ? "Never (Lifetime)"
                          : new Date(addedKey.expires).toLocaleString()}
                      </div>
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="relative z-10">
                  <Button
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all"
                    onClick={() => setAddedKey(null)}
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Create Another Key
                  </Button>
                </CardFooter>
              </Card>
            )}

            <Card className="border-slate-800/50 bg-slate-900/50 backdrop-blur-sm shadow-xl overflow-hidden relative">
              <div className="absolute inset-0 bg-grid-white/5 mask-linear-gradient-to-b from-transparent to-black"></div>

              <CardHeader className="relative z-10">
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5 text-purple-500" />
                  Create Premium Key
                </CardTitle>
                <CardDescription>Add a new premium key with extended duration</CardDescription>
              </CardHeader>

              <CardContent className="space-y-6 relative z-10">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="key" className="flex items-center gap-1.5">
                      <Key className="h-4 w-4 text-purple-500" />
                      Key
                    </Label>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs text-purple-400 hover:text-purple-300"
                      onClick={generateRandomKey}
                      disabled={isGeneratingKey}
                    >
                      {isGeneratingKey ? (
                        <>
                          <RefreshCw className="mr-1 h-3 w-3 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Sparkles className="mr-1 h-3 w-3" />
                          Generate Random
                        </>
                      )}
                    </Button>
                  </div>
                  <div className="relative">
                    <Input
                      id="key"
                      placeholder="Enter premium key (e.g., VEXOS-PREMIUM-123456)"
                      value={key}
                      onChange={(e) => setKey(e.target.value)}
                      className="pl-10 bg-slate-950/50 border-slate-800 focus:border-purple-500"
                    />
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
                      <Key className="h-4 w-4" />
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="flex items-center gap-1.5">
                    <Clock className="h-4 w-4 text-purple-500" />
                    Duration
                  </Label>

                  <RadioGroup value={duration} onValueChange={setDuration} className="hidden">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="1week" id="1week" />
                      <Label htmlFor="1week">1 Week</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="1month" id="1month" />
                      <Label htmlFor="1month">1 Month</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="1year" id="1year" />
                      <Label htmlFor="1year">1 Year</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="lifetime" id="lifetime" />
                      <Label htmlFor="lifetime">Lifetime</Label>
                    </div>
                  </RadioGroup>

                  <div className="grid grid-cols-2 gap-3">
                    <div
                      className={`border rounded-lg p-3 cursor-pointer transition-all ${
                        duration === "1week"
                          ? "border-purple-500 bg-purple-500/10 text-white"
                          : "border-slate-800 bg-slate-900/30 text-slate-400 hover:bg-slate-900/50"
                      }`}
                      onClick={() => setDuration("1week")}
                    >
                      <div className="flex flex-col items-center justify-center">
                        <span className="text-lg font-bold">1 Week</span>
                        <span className="text-xs opacity-70">7 days access</span>
                      </div>
                    </div>

                    <div
                      className={`border rounded-lg p-3 cursor-pointer transition-all ${
                        duration === "1month"
                          ? "border-purple-500 bg-purple-500/10 text-white"
                          : "border-slate-800 bg-slate-900/30 text-slate-400 hover:bg-slate-900/50"
                      }`}
                      onClick={() => setDuration("1month")}
                    >
                      <div className="flex flex-col items-center justify-center">
                        <span className="text-lg font-bold">1 Month</span>
                        <span className="text-xs opacity-70">30 days access</span>
                      </div>
                    </div>

                    <div
                      className={`border rounded-lg p-3 cursor-pointer transition-all ${
                        duration === "1year"
                          ? "border-purple-500 bg-purple-500/10 text-white"
                          : "border-slate-800 bg-slate-900/30 text-slate-400 hover:bg-slate-900/50"
                      }`}
                      onClick={() => setDuration("1year")}
                    >
                      <div className="flex flex-col items-center justify-center">
                        <span className="text-lg font-bold">1 Year</span>
                        <span className="text-xs opacity-70">365 days access</span>
                      </div>
                    </div>

                    <div
                      className={`border rounded-lg p-3 cursor-pointer transition-all ${
                        duration === "lifetime"
                          ? "border-pink-500 bg-pink-500/10 text-white"
                          : "border-slate-800 bg-slate-900/30 text-slate-400 hover:bg-slate-900/50"
                      }`}
                      onClick={() => setDuration("lifetime")}
                    >
                      <div className="flex flex-col items-center justify-center">
                        <span className="text-lg font-bold">Lifetime</span>
                        <span className="text-xs opacity-70">Permanent access</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>

              <CardFooter className="relative z-10">
                <Button
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all"
                  onClick={handleAddKey}
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  Add Premium Key
                </Button>
              </CardFooter>
            </Card>

            <div className="mt-6 bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 text-sm text-yellow-300">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-yellow-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium mb-1">Developer Access Only</p>
                  <p className="text-yellow-300/80">
                    This page is restricted to VEXOS developers. Adding premium keys requires authentication.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Password Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-slate-900 border border-purple-500/30 rounded-lg max-w-md w-full p-6 shadow-xl relative overflow-hidden animate-scale-in">
            <div className="absolute inset-0 bg-grid-white/5"></div>
            <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent"></div>
            <div className="absolute bottom-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-pink-500 to-transparent"></div>

            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center">
                  <Shield className="h-5 w-5 text-purple-500" />
                </div>
                <h3 className="text-xl font-bold">Developer Authentication</h3>
              </div>

              <p className="text-slate-400 mb-6">Please enter the developer password to add this premium key</p>

              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="password" className="flex items-center gap-2">
                    <Lock className="h-4 w-4 text-purple-500" />
                    Password
                  </Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type="password"
                      placeholder="Enter developer password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 bg-slate-950/50 border-slate-800 focus:border-purple-500"
                    />
                    <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">
                      <Lock className="h-4 w-4" />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    className="flex-1 border-slate-700 hover:bg-slate-800 hover:text-white"
                    onClick={handleCancelAdd}
                    disabled={isLoading}
                  >
                    Cancel
                  </Button>
                  <Button
                    className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg shadow-purple-500/20"
                    onClick={handleConfirmAdd}
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Shield className="mr-2 h-4 w-4" />
                        Authenticate
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <Footer />

      <style jsx global>{`
       @keyframes blob {
         0% {
           transform: translate(0px, 0px) scale(1);
         }
         33% {
           transform: translate(30px, -50px) scale(1.1);
         }
         66% {
           transform: translate(-20px, 20px) scale(0.9);
         }
         100% {
           transform: translate(0px, 0px) scale(1);
         }
       }
       
       @keyframes shake {
         0%, 100% { transform: translateX(0); }
         10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
         20%, 40%, 60%, 80% { transform: translateX(5px); }
       }
       
       @keyframes fade-in {
         from { opacity: 0; }
         to { opacity: 1; }
       }
       
       @keyframes scale-in {
         from { transform: scale(0.95); opacity: 0; }
         to { transform: scale(1); opacity: 1; }
       }
       
       @keyframes fade-in-out {
         0% { opacity: 0; }
         20% { opacity: 1; }
         80% { opacity: 1; }
         100% { opacity: 0; }
       }
       
       .animate-blob {
         animation: blob 7s infinite;
       }
       
       .animation-delay-2000 {
         animation-delay: 2s;
       }
       
       .animation-delay-4000 {
         animation-delay: 4s;
       }
       
       .animate-shake {
         animation: shake 0.5s cubic-bezier(.36,.07,.19,.97) both;
       }
       
       .animate-fade-in {
         animation: fade-in 0.3s ease-out;
       }
       
       .animate-scale-in {
         animation: scale-in 0.3s ease-out;
       }
       
       .animate-fade-in-out {
         animation: fade-in-out 2s ease-out;
       }
       
       .bg-grid-white\/5 {
         background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32' width='32' height='32' fill='none' stroke='rgb(255 255 255 / 0.05)'%3e%3cpath d='M0 .5H31.5V32'/%3e%3c/svg%3e");
       }
       
       .mask-linear-gradient-to-b {
         mask-image: linear-gradient(to bottom, transparent, black);
         -webkit-mask-image: linear-gradient(to bottom, transparent, black);
       }
     `}</style>
    </div>
  )
}

