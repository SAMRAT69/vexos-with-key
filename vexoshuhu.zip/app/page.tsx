"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Download, Shield, Zap, BookOpen, RefreshCw, Rocket, Key, Code } from "lucide-react"
import FeatureCard from "@/components/feature-card"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { generateHWID } from "@/lib/hwid"
import { useRouter } from "next/navigation"

export default function Home() {
  const [hwid, setHwid] = useState("")
  const router = useRouter()

  useEffect(() => {
    // Generate HWID on component mount
    const generatedHWID = generateHWID()
    setHwid(generatedHWID)
  }, [])

  const handleGetKey = () => {
    router.push(`/keysystem?hwid=${hwid}`)
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-slate-900 to-slate-950">
      <Navbar />

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden" id="home">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(124,58,237,0.15)_0%,transparent_70%)] z-0"></div>
        <div className="lightning absolute inset-0 opacity-0 bg-purple-500/10 z-0 animate-lightning"></div>

        <div className="container px-4 mx-auto relative z-10">
          <div className="flex flex-col lg:flex-row items-center">
            <div className="w-full lg:w-1/2 mb-12 lg:mb-0 animate-slideInUp">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-purple-500">
                The Ultimate Roblox Executor Experience
              </h1>
              <p className="text-slate-400 text-lg mb-8 max-w-xl">
                VEXOS delivers unmatched script execution power with a revolutionary interface designed for the modern
                Roblox player.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 animate-pulse shadow-lg shadow-purple-500/20"
                >
                  <Download className="mr-2 h-5 w-5" />
                  Download Now
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-purple-500 text-purple-500 hover:bg-purple-500/10"
                  onClick={handleGetKey}
                >
                  <Key className="mr-2 h-5 w-5" />
                  Get Key
                </Button>
              </div>

              <div className="flex flex-wrap gap-3 mt-8">
                <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-full px-4 py-2 text-sm font-medium flex items-center">
                  <span className="mr-2">📱</span> Mobile Available
                </div>
                <div className="border border-dashed border-slate-700 rounded-full px-4 py-2 text-sm font-medium text-slate-400 flex items-center">
                  <span className="mr-2">🍎</span> iOS Coming Soon
                </div>
                <div className="border border-dashed border-slate-700 rounded-full px-4 py-2 text-sm font-medium text-slate-400 flex items-center">
                  <span className="mr-2">🪟</span> Windows Coming Soon
                </div>
              </div>
            </div>

            <div className="w-full lg:w-1/2 flex justify-center">
              <div className="relative w-full max-w-md animate-float">
                <Image
                  src="/placeholder.svg?height=600&width=300"
                  alt="VEXOS Interface"
                  width={300}
                  height={600}
                  className="rounded-xl shadow-2xl shadow-purple-500/20"
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/20 to-transparent rounded-xl"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-slate-900 relative" id="features">
        <div className="container px-4 mx-auto relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-purple-500 inline-block">
              Revolutionary Features
            </h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              VEXOS redefines what's possible with cutting-edge technology and innovative design
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={<Zap className="w-10 h-10 text-purple-500" />}
              title="Level 8 Execution"
              description="Execute any script with our powerful Level 8 executor that can handle even the most complex scripts with lightning-fast performance."
            />
            <FeatureCard
              icon={<Shield className="w-10 h-10 text-purple-500" />}
              title="Advanced Protection"
              description="Our proprietary anti-detection system keeps your account safe with military-grade encryption and intelligent behavior analysis."
            />
            <FeatureCard
              icon={<BookOpen className="w-10 h-10 text-purple-500" />}
              title="Premium Script Library"
              description="Access our extensive collection of exclusive, optimized scripts for all popular games with one-click execution."
            />
            <FeatureCard
              icon={<RefreshCw className="w-10 h-10 text-purple-500" />}
              title="Real-time Updates"
              description="Stay ahead with our instant update system that adapts to Roblox changes within minutes, not hours or days."
            />
            <FeatureCard
              icon={<Zap className="w-10 h-10 text-purple-500" />}
              title="Blazing Fast Execution"
              description="Run scripts instantly with zero delay using our highly optimized execution engine, ensuring smooth and lag-free performance every time."
            />
            <FeatureCard
              icon={<Rocket className="w-10 h-10 text-purple-500" />}
              title="Quantum Injection"
              description="Experience near-instantaneous script injection with our proprietary Quantum Injection technology, exclusive to VEXOS."
            />
          </div>
        </div>
      </section>

      {/* API Documentation Section */}
      <section className="py-20 bg-slate-950/80 relative" id="api">
        <div className="container px-4 mx-auto relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-purple-500 inline-block">
              Developer API
            </h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Integrate VEXOS into your own applications with our comprehensive API
            </p>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 md:p-8 mb-8">
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <Code className="mr-2 h-5 w-5 text-purple-500" />
              Authentication
            </h3>
            <p className="text-slate-400 mb-4">All API requests require authentication using your API key.</p>
            <div className="bg-slate-950 rounded-lg p-4 overflow-x-auto">
              <pre className="text-sm text-slate-300">
                <code>{`// Example API request with authentication
fetch('https://api.vexos.io/v1/execute', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({
    script: 'print("Hello from VEXOS!")',
    game_id: 1234567890
  })
})`}</code>
              </pre>
            </div>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 md:p-8 mb-8">
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <Code className="mr-2 h-5 w-5 text-purple-500" />
              Script Execution
            </h3>
            <p className="text-slate-400 mb-4">Execute scripts remotely using our API.</p>
            <div className="bg-slate-950 rounded-lg p-4 overflow-x-auto">
              <pre className="text-sm text-slate-300">
                <code>{`// Endpoint: POST /v1/execute
// Request body:
{
  "script": "your Lua script here",
  "game_id": 1234567890,
  "options": {
    "bypass_anticheat": true,
    "execution_level": 8
  }
}

// Response:
{
  "success": true,
  "execution_id": "ex_12345",
  "status": "completed"
}`}</code>
              </pre>
            </div>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 md:p-8">
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <Code className="mr-2 h-5 w-5 text-purple-500" />
              Key Verification
            </h3>
            <p className="text-slate-400 mb-4">Verify user keys through our API.</p>
            <div className="bg-slate-950 rounded-lg p-4 overflow-x-auto">
              <pre className="text-sm text-slate-300">
                <code>{`// Endpoint: POST /v1/verify-key
// Request body:
{
  "key": "user-provided-key",
  "hwid": "user-hardware-id"
}

// Response:
{
  "valid": true,
  "expires_at": "2023-12-31T23:59:59Z",
  "tier": "premium"
}`}</code>
              </pre>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              View Full API Documentation
            </Button>
          </div>
        </div>
      </section>

      {/* Download Section */}
      <section className="py-20 bg-slate-900 relative" id="download">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(124,58,237,0.15)_0%,transparent_70%)] z-0"></div>

        <div className="container px-4 mx-auto relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-purple-500 inline-block">
              Download VEXOS Now
            </h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              Currently available for Mobile devices, with iOS, Windows and macOS versions coming very soon!
            </p>
          </div>

          <div className="flex flex-col items-center">
            <Button
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 animate-pulse shadow-lg shadow-purple-500/20 mb-12"
            >
              <Download className="mr-2 h-5 w-5" />
              Download For Mobile
            </Button>

            <div className="relative w-full max-w-xs mb-12 animate-float">
              <Image
                src="/placeholder.svg?height=600&width=300"
                alt="VEXOS Mobile App"
                width={300}
                height={600}
                className="rounded-xl shadow-2xl shadow-purple-500/20"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/20 to-transparent rounded-xl"></div>
            </div>

            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 md:p-8 w-full max-w-3xl">
              <h3 className="text-xl font-bold mb-6 text-center">Latest Mobile Release</h3>

              <div className="grid grid-cols-3 gap-8 mb-8">
                <div className="text-center">
                  <p className="text-2xl font-bold text-purple-500 mb-2">v1.0.0</p>
                  <p className="text-sm text-slate-400">Version</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-purple-500 mb-2">0 MB</p>
                  <p className="text-sm text-slate-400">Size</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-purple-500 mb-2">Soon</p>
                  <p className="text-sm text-slate-400">Released</p>
                </div>
              </div>

              <p className="text-slate-400 text-center mb-8">
                Our latest mobile version includes enhanced script execution, revolutionary 3D UI, and improved
                compatibility with all Roblox games.
              </p>

              <h3 className="text-xl font-bold mb-6 text-center">Coming Soon To More Platforms</h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div className="flex flex-col items-center">
                  <div className="text-4xl mb-2">🍎</div>
                  <p className="font-medium mb-1">iOS</p>
                  <span className="bg-slate-800 text-pink-500 text-xs px-3 py-1 rounded-full">Not Started</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="text-4xl mb-2">🪟</div>
                  <p className="font-medium mb-1">Windows</p>
                  <span className="bg-slate-800 text-pink-500 text-xs px-3 py-1 rounded-full">Not Started</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="text-4xl mb-2">🍏</div>
                  <p className="font-medium mb-1">macOS</p>
                  <span className="bg-slate-800 text-pink-500 text-xs px-3 py-1 rounded-full">Not Started</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}

