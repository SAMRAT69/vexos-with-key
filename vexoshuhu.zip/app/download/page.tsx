import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Download, Shield, Key } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function DownloadPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-slate-900 to-slate-950">
      <Navbar />

      <main className="flex-1 pt-24">
        <div className="container px-4 mx-auto py-12">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-purple-500 inline-block">
                Download VEXOS Executor
              </h1>
              <p className="text-slate-400 max-w-2xl mx-auto">Get the latest version of our powerful Roblox executor</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 md:p-8 flex flex-col items-center text-center">
                <div className="w-20 h-20 rounded-full bg-purple-500/20 flex items-center justify-center mb-6">
                  <Download className="w-10 h-10 text-purple-500" />
                </div>
                <h2 className="text-2xl font-bold mb-2">Mobile Version</h2>
                <p className="text-slate-400 mb-6">Our Android version with full script execution capabilities</p>
                <div className="grid grid-cols-3 gap-4 w-full mb-6">
                  <div className="text-center">
                    <p className="text-xl font-bold text-purple-500">v1.0.0</p>
                    <p className="text-xs text-slate-500">Version</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xl font-bold text-purple-500">0 MB</p>
                    <p className="text-xs text-slate-500">Size</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xl font-bold text-purple-500">Soon</p>
                    <p className="text-xs text-slate-500">Released</p>
                  </div>
                </div>
                <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                  Download for Android
                </Button>
              </div>

              <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 md:p-8 flex flex-col items-center text-center">
                <div className="w-20 h-20 rounded-full bg-slate-800/50 flex items-center justify-center mb-6">
                  <Download className="w-10 h-10 text-slate-500" />
                </div>
                <h2 className="text-2xl font-bold mb-2">Windows Version</h2>
                <p className="text-slate-400 mb-6">Our Windows version with advanced features and optimizations</p>
                <div className="grid grid-cols-3 gap-4 w-full mb-6">
                  <div className="text-center">
                    <p className="text-xl font-bold text-slate-500">TBA</p>
                    <p className="text-xs text-slate-500">Version</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xl font-bold text-slate-500">TBA</p>
                    <p className="text-xs text-slate-500">Size</p>
                  </div>
                  <div className="text-center">
                    <p className="text-xl font-bold text-slate-500">Coming Soon</p>
                    <p className="text-xs text-slate-500">Released</p>
                  </div>
                </div>
                <Button disabled className="w-full bg-slate-800 text-slate-400 cursor-not-allowed">
                  Coming Soon
                </Button>
              </div>
            </div>

            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 md:p-8 mb-12">
              <div className="flex items-center gap-4 mb-6">
                <Key className="w-6 h-6 text-purple-500" />
                <h2 className="text-2xl font-bold">Don't Forget Your Key</h2>
              </div>

              <p className="text-slate-400 mb-6">
                You'll need a valid key to use VEXOS Executor. Keys are valid for 24 hours and are tied to your hardware
                ID for security.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  asChild
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  <Link href="/keysystem">Get a Key</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link href="/api-docs">View API Docs</Link>
                </Button>
              </div>
            </div>

            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 md:p-8">
              <div className="flex items-center gap-4 mb-6">
                <Shield className="w-6 h-6 text-purple-500" />
                <h2 className="text-2xl font-bold">Installation Instructions</h2>
              </div>

              <div className="space-y-6">
                <div className="flex items-start">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-purple-500/20 text-purple-500 mr-3 shrink-0 mt-0.5">
                    1
                  </span>
                  <div>
                    <h3 className="font-medium mb-1">Download the Executor</h3>
                    <p className="text-slate-400">
                      Click the download button above to get the latest version of VEXOS Executor.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-purple-500/20 text-purple-500 mr-3 shrink-0 mt-0.5">
                    2
                  </span>
                  <div>
                    <h3 className="font-medium mb-1">Generate a Key</h3>
                    <p className="text-slate-400">
                      Visit our key system page to generate a unique key for your device.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-purple-500/20 text-purple-500 mr-3 shrink-0 mt-0.5">
                    3
                  </span>
                  <div>
                    <h3 className="font-medium mb-1">Install the Executor</h3>
                    <p className="text-slate-400">
                      Run the installer and follow the on-screen instructions to complete the installation.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-purple-500/20 text-purple-500 mr-3 shrink-0 mt-0.5">
                    4
                  </span>
                  <div>
                    <h3 className="font-medium mb-1">Enter Your Key</h3>
                    <p className="text-slate-400">Launch the executor and enter your key when prompted.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-purple-500/20 text-purple-500 mr-3 shrink-0 mt-0.5">
                    5
                  </span>
                  <div>
                    <h3 className="font-medium mb-1">Start Executing Scripts</h3>
                    <p className="text-slate-400">
                      Once verified, you can start executing scripts in your favorite Roblox games!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

