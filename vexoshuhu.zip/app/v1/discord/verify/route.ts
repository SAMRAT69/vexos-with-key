import { NextResponse } from "next/server"

// In-memory database for tracking discord verification
// In a real app, use a database
interface DiscordVerification {
  hwid: string
  verified: boolean
  timestamp: Date
}

const discordVerifications: Record<string, DiscordVerification> = {}

// Discord server invite link
const DISCORD_INVITE = "https://discord.gg/your-server-invite"

export async function POST(request: Request) {
  try {
    const { hwid, action } = await request.json()

    // Validate request
    if (!hwid) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing hardware ID",
        },
        { status: 400 },
      )
    }

    if (action === "getlink") {
      return NextResponse.json({
        success: true,
        discordLink: DISCORD_INVITE,
      })
    } else if (action === "verify") {
      // In a real implementation, you would verify if the user actually joined
      // For this example, we'll just mark it as verified

      discordVerifications[hwid] = {
        hwid,
        verified: true,
        timestamp: new Date(),
      }

      return NextResponse.json({
        success: true,
        verified: true,
        message: "Discord verification completed",
      })
    } else if (action === "check") {
      const verification = discordVerifications[hwid]

      if (!verification) {
        return NextResponse.json({
          success: true,
          verified: false,
          message: "Discord verification not completed",
        })
      }

      return NextResponse.json({
        success: true,
        verified: verification.verified,
        timestamp: verification.timestamp,
        message: verification.verified ? "Discord verification completed" : "Discord verification not completed",
      })
    } else {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid action. Must be 'getlink', 'verify', or 'check'",
        },
        { status: 400 },
      )
    }
  } catch (error) {
    console.error("Error verifying Discord:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to verify Discord",
      },
      { status: 500 },
    )
  }
}

