import { NextResponse } from "next/server"

// In-memory database for tracking adlink verification
// In a real app, use a database
interface AdlinkVerification {
  hwid: string
  startTime: Date
  completed: boolean
  timeSpent: number // in seconds
}

const adlinkVerifications: Record<string, AdlinkVerification> = {}

export async function POST(request: Request) {
  try {
    const { hwid, action } = await request.json()

    // Validate request
    if (!hwid) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing hardware ID",
        },
        { status: 400 },
      )
    }

    // Handle different actions
    if (action === "start") {
      // Start the adlink timer
      adlinkVerifications[hwid] = {
        hwid,
        startTime: new Date(),
        completed: false,
        timeSpent: 0,
      }

      return NextResponse.json({
        success: true,
        message: "Adlink timer started",
        requiredTime: 30, // 30 seconds required
        verification: adlinkVerifications[hwid],
      })
    } else if (action === "check") {
      // Check if the adlink verification exists
      if (!adlinkVerifications[hwid]) {
        return NextResponse.json(
          {
            success: false,
            error: "No active adlink verification found",
          },
          { status: 404 },
        )
      }

      const verification = adlinkVerifications[hwid]
      const now = new Date()
      const timeSpent = Math.floor((now.getTime() - verification.startTime.getTime()) / 1000)

      verification.timeSpent = timeSpent

      // Check if enough time has passed
      if (timeSpent >= 30) {
        verification.completed = true
      }

      return NextResponse.json({
        success: true,
        completed: verification.completed,
        timeSpent,
        requiredTime: 30,
        remaining: Math.max(0, 30 - timeSpent),
      })
    } else {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid action. Must be 'start' or 'check'",
        },
        { status: 400 },
      )
    }
  } catch (error) {
    console.error("Error verifying adlink:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to verify adlink",
      },
      { status: 500 },
    )
  }
}

