import { NextResponse } from "next/server"

// In-memory database for tracking key generation process
// In a real app, use a database
interface StepData {
  completed: boolean
  timestamp: Date | null
}

interface ProcessData {
  hwid: string
  ip: string
  steps: {
    adlink: StepData
    discord: StepData
    verify: StepData
  }
  startedAt: Date
  lastUpdated: Date
  completedAt: Date | null
}

// Global in-memory database for process tracking
const processDatabase: Record<string, ProcessData> = {}

// Local storage key for browser persistence
const PROCESS_STORAGE_KEY = "vexos_keysystem_progress"

export async function POST(request: Request) {
  try {
    const { hwid, step, action } = await request.json()

    // Get client IP address
    const forwardedFor = request.headers.get("x-forwarded-for")
    const ip = forwardedFor ? forwardedFor.split(",")[0] : "unknown"

    // Validate request
    if (!hwid) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing hardware ID",
        },
        { status: 400 },
      )
    }

    // Initialize or get process data
    if (!processDatabase[hwid]) {
      processDatabase[hwid] = {
        hwid,
        ip,
        steps: {
          adlink: { completed: false, timestamp: null },
          discord: { completed: false, timestamp: null },
          verify: { completed: false, timestamp: null },
        },
        startedAt: new Date(),
        lastUpdated: new Date(),
        completedAt: null,
      }
    }

    const processData = processDatabase[hwid]

    // Update process data if step and action are provided
    if (step && action === "complete" && processData.steps[step as keyof typeof processData.steps] !== undefined) {
      processData.steps[step as keyof typeof processData.steps] = {
        completed: true,
        timestamp: new Date(),
      }
      processData.lastUpdated = new Date()

      // Check if all steps are completed
      const allCompleted = Object.values(processData.steps).every((s) => s.completed)
      if (allCompleted && !processData.completedAt) {
        processData.completedAt = new Date()
      }
    } else if (action === "reset") {
      // Reset progress for this HWID
      processDatabase[hwid] = {
        hwid,
        ip,
        steps: {
          adlink: { completed: false, timestamp: null },
          discord: { completed: false, timestamp: null },
          verify: { completed: false, timestamp: null },
        },
        startedAt: new Date(),
        lastUpdated: new Date(),
        completedAt: null,
      }
    }

    // Calculate progress
    const totalSteps = Object.keys(processData.steps).length
    const completedSteps = Object.values(processData.steps).filter((s) => s.completed).length
    const progress = Math.round((completedSteps / totalSteps) * 100)

    // Find next incomplete step
    let nextStep = null
    for (const [key, value] of Object.entries(processData.steps)) {
      if (!value.completed) {
        nextStep = key
        break
      }
    }

    // Prepare response data
    const responseData = {
      success: true,
      hwid,
      progress,
      steps: processData.steps,
      startedAt: processData.startedAt,
      lastUpdated: processData.lastUpdated,
      completedAt: processData.completedAt,
      completed: progress === 100,
      nextStep,
    }

    return NextResponse.json(responseData)
  } catch (error) {
    console.error("Error tracking key process:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to track key process",
      },
      { status: 500 },
    )
  }
}

// Get progress for a specific HWID
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hwid = searchParams.get("hwid")

    if (!hwid) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing hardware ID",
        },
        { status: 400 },
      )
    }

    // Get process data for this HWID
    const processData = processDatabase[hwid]

    if (!processData) {
      return NextResponse.json({
        success: true,
        hwid,
        progress: 0,
        steps: {
          adlink: { completed: false, timestamp: null },
          discord: { completed: false, timestamp: null },
          verify: { completed: false, timestamp: null },
        },
        startedAt: null,
        lastUpdated: null,
        completedAt: null,
        completed: false,
        nextStep: "adlink",
      })
    }

    // Calculate progress
    const totalSteps = Object.keys(processData.steps).length
    const completedSteps = Object.values(processData.steps).filter((s) => s.completed).length
    const progress = Math.round((completedSteps / totalSteps) * 100)

    // Find next incomplete step
    let nextStep = null
    for (const [key, value] of Object.entries(processData.steps)) {
      if (!value.completed) {
        nextStep = key
        break
      }
    }

    return NextResponse.json({
      success: true,
      hwid,
      progress,
      steps: processData.steps,
      startedAt: processData.startedAt,
      lastUpdated: processData.lastUpdated,
      completedAt: processData.completedAt,
      completed: progress === 100,
      nextStep,
    })
  } catch (error) {
    console.error("Error getting key process:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to get key process",
      },
      { status: 500 },
    )
  }
}

