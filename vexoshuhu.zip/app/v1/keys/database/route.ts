import { NextResponse } from "next/server"
import { premiumKeys } from "@/lib/premium-keys"

// In-memory database of all keys (in a real app, this would be in a database)
interface KeyRecord {
  key: string
  hwid: string | null
  keyType: "premium" | "freemium"
  expiresAt: Date
  createdAt: Date
  createdBy: string
  isRevoked: boolean
  revokedAt: Date | null
  revokedReason: string | null
  usageCount: number
  lastUsed: Date | null
  metadata: Record<string, any>
}

// Global in-memory database for all keys
const keyDatabase: Record<string, KeyRecord> = {}

// Initialize database with premium keys
function initializeKeyDatabase() {
  // Add premium keys to database
  Object.entries(premiumKeys).forEach(([keyString, keyData]) => {
    if (!keyDatabase[keyString]) {
      keyDatabase[keyString] = {
        key: keyString,
        hwid: null, // Will be set on first use
        keyType: "premium",
        expiresAt: keyData.expires,
        createdAt: new Date(Date.now() - 86400000), // Assume created 1 day ago
        createdBy: "system",
        isRevoked: false,
        revokedAt: null,
        revokedReason: null,
        usageCount: 0,
        lastUsed: null,
        metadata: {
          duration: keyData.duration,
          source: "premium-keys.ts",
        },
      }
    }
  })
}

// Initialize the database on module load
initializeKeyDatabase()

// Admin authentication function
function authenticateAdmin(adminKey: string): boolean {
  // In a real app, use a more secure authentication method
  return adminKey === "VEXOS-ADMIN-KEY"
}

export async function GET(request: Request) {
  try {
    // Get the admin key from the URL query parameters
    const { searchParams } = new URL(request.url)
    const adminKey = searchParams.get("adminKey")

    // Check admin authentication
    if (!adminKey || !authenticateAdmin(adminKey)) {
      return NextResponse.json(
        {
          success: false,
          error: "Unauthorized access",
        },
        { status: 401 },
      )
    }

    // Get optional filters
    const keyType = searchParams.get("keyType")
    const isRevoked = searchParams.get("isRevoked")
    const limit = Number.parseInt(searchParams.get("limit") || "100")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    // Filter and paginate results
    let filteredKeys = Object.values(keyDatabase)

    if (keyType) {
      filteredKeys = filteredKeys.filter((k) => k.keyType === keyType)
    }

    if (isRevoked !== null) {
      const revokedBool = isRevoked === "true"
      filteredKeys = filteredKeys.filter((k) => k.isRevoked === revokedBool)
    }

    // Sort by creation date (newest first)
    filteredKeys.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())

    // Apply pagination
    const paginatedKeys = filteredKeys.slice(offset, offset + limit)

    return NextResponse.json({
      success: true,
      total: filteredKeys.length,
      limit,
      offset,
      keys: paginatedKeys,
    })
  } catch (error) {
    console.error("Error accessing key database:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to access key database",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: Request) {
  try {
    const { adminKey, action, key, data } = await request.json()

    // Check admin authentication
    if (!adminKey || !authenticateAdmin(adminKey)) {
      return NextResponse.json(
        {
          success: false,
          error: "Unauthorized access",
        },
        { status: 401 },
      )
    }

    // Handle different actions
    switch (action) {
      case "add":
        // Add a new key to the database
        if (!data || !data.key || !data.keyType || !data.expiresAt) {
          return NextResponse.json(
            {
              success: false,
              error: "Missing required key data",
            },
            { status: 400 },
          )
        }

        // Create new key record
        const newKey: KeyRecord = {
          key: data.key,
          hwid: data.hwid || null,
          keyType: data.keyType,
          expiresAt: new Date(data.expiresAt),
          createdAt: new Date(),
          createdBy: data.createdBy || "admin",
          isRevoked: false,
          revokedAt: null,
          revokedReason: null,
          usageCount: 0,
          lastUsed: null,
          metadata: data.metadata || {},
        }

        keyDatabase[data.key] = newKey

        return NextResponse.json({
          success: true,
          message: "Key added successfully",
          key: newKey,
        })

      case "revoke":
        // Revoke an existing key
        if (!key) {
          return NextResponse.json(
            {
              success: false,
              error: "Missing key to revoke",
            },
            { status: 400 },
          )
        }

        if (!keyDatabase[key]) {
          return NextResponse.json(
            {
              success: false,
              error: "Key not found",
            },
            { status: 404 },
          )
        }

        keyDatabase[key].isRevoked = true
        keyDatabase[key].revokedAt = new Date()
        keyDatabase[key].revokedReason = data?.reason || "Revoked by admin"

        return NextResponse.json({
          success: true,
          message: "Key revoked successfully",
          key: keyDatabase[key],
        })

      case "update":
        // Update an existing key
        if (!key || !data) {
          return NextResponse.json(
            {
              success: false,
              error: "Missing key or update data",
            },
            { status: 400 },
          )
        }

        if (!keyDatabase[key]) {
          return NextResponse.json(
            {
              success: false,
              error: "Key not found",
            },
            { status: 404 },
          )
        }

        // Update allowed fields
        if (data.hwid !== undefined) keyDatabase[key].hwid = data.hwid
        if (data.expiresAt) keyDatabase[key].expiresAt = new Date(data.expiresAt)
        if (data.isRevoked !== undefined) {
          keyDatabase[key].isRevoked = data.isRevoked
          if (data.isRevoked) {
            keyDatabase[key].revokedAt = new Date()
            keyDatabase[key].revokedReason = data.revokedReason || "Updated by admin"
          }
        }
        if (data.metadata) {
          keyDatabase[key].metadata = {
            ...keyDatabase[key].metadata,
            ...data.metadata,
          }
        }

        return NextResponse.json({
          success: true,
          message: "Key updated successfully",
          key: keyDatabase[key],
        })

      default:
        return NextResponse.json(
          {
            success: false,
            error: "Invalid action. Must be 'add', 'revoke', or 'update'",
          },
          { status: 400 },
        )
    }
  } catch (error) {
    console.error("Error managing key database:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to manage key database",
      },
      { status: 500 },
    )
  }
}

