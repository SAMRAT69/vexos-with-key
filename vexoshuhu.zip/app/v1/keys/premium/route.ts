// This file is deleted as premium keys will now be hardcoded in the source

