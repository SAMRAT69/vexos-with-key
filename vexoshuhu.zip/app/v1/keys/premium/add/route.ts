import { NextResponse } from "next/server"
import fs from "fs"
import path from "path"

// Developer password for adding premium keys
const DEVELOPER_PASSWORD = "VEXOSONTOPYEY"

// Path to premium keys file
const PREMIUM_KEYS_FILE_PATH = path.join(process.cwd(), "lib", "premium-keys.ts")

export async function POST(request: Request) {
  try {
    const { key, duration, password } = await request.json()

    // Validate request
    if (!key || !duration || !password) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing required parameters",
        },
        { status: 400 },
      )
    }

    // Validate duration
    if (!["1week", "1month", "1year", "lifetime"].includes(duration)) {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid duration. Must be one of: 1week, 1month, 1year, lifetime",
        },
        { status: 400 },
      )
    }

    // Verify developer password
    if (password !== DEVELOPER_PASSWORD) {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid developer password",
        },
        { status: 401 },
      )
    }

    // Set expiration date based on duration
    const expires = new Date()
    switch (duration) {
      case "1week":
        expires.setDate(expires.getDate() + 7)
        break
      case "1month":
        expires.setMonth(expires.getMonth() + 1)
        break
      case "1year":
        expires.setFullYear(expires.getFullYear() + 1)
        break
      case "lifetime":
        expires.setFullYear(expires.getFullYear() + 100) // 100 years is effectively lifetime
        break
    }

    // In a real application, you would add this to a database
    // For this example, we'll update the premium-keys.ts file
    // Note: This is not recommended for production as it modifies source code
    // In production, use a database instead

    // Read the current premium keys file
    let premiumKeysContent = fs.readFileSync(PREMIUM_KEYS_FILE_PATH, "utf8")

    // Add the new key to the premium keys object
    const newKeyEntry = `
  "${key}": {
    key: "${key}",
    keyType: "premium",
    duration: "${duration}",
    expires: new Date("${expires.toISOString()}"),
  },`

    // Insert the new key before the closing brace of the premiumKeys object
    const insertPosition = premiumKeysContent.lastIndexOf("};")
    if (insertPosition !== -1) {
      premiumKeysContent =
        premiumKeysContent.substring(0, insertPosition) + newKeyEntry + premiumKeysContent.substring(insertPosition)

      // Write the updated content back to the file
      fs.writeFileSync(PREMIUM_KEYS_FILE_PATH, premiumKeysContent, "utf8")
    }

    return NextResponse.json({
      success: true,
      key,
      expires,
      keyType: "premium",
      duration,
      message: `Premium key added successfully. Valid for ${duration === "lifetime" ? "lifetime" : duration}.`,
    })
  } catch (error) {
    console.error("Error adding premium key:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to add premium key",
      },
      { status: 500 },
    )
  }
}

