import { NextResponse } from "next/server"
import { v4 as uuidv4 } from "uuid"

// In a real application, this would be stored in a database
interface KeyData {
  key: string
  hwid: string
  expires: Date
  used: boolean
  createdAt: Date
  ip: string
  keyType: "premium" | "freemium"
  duration: "24h" | "1week" | "1month" | "1year" | "lifetime"
  lastGenerated: Date
}

// Simulated database of keys
const keysDatabase: Record<string, KeyData> = {}

// HWID to last key generation time mapping
const hwidLastGeneration: Record<string, Date> = {}

// Global key database for tracking all keys
interface KeyRecord {
  key: string
  hwid: string
  keyType: "premium" | "freemium"
  expiresAt: Date
  createdAt: Date
  createdBy: string
  isRevoked: boolean
  revokedAt: Date | null
  revokedReason: string | null
  usageCount: number
  lastUsed: Date | null
  metadata: Record<string, any>
}

// Global in-memory database for all keys
const keyDatabase: Record<string, KeyRecord> = {}

export async function POST(request: Request) {
  try {
    const { hwid, keyType = "freemium", duration = "24h" } = await request.json()

    // Get client IP address
    const forwardedFor = request.headers.get("x-forwarded-for")
    const ip = forwardedFor ? forwardedFor.split(",")[0] : "unknown"

    // Validate request
    if (!hwid) {
      return NextResponse.json(
        {
          success: false,
          error: "Missing hardware ID",
        },
        { status: 400 },
      )
    }

    // Check if this HWID has generated a key recently (for freemium keys)
    const now = new Date()
    if (keyType === "freemium" && hwidLastGeneration[hwid]) {
      const lastGen = hwidLastGeneration[hwid]
      const hoursSinceLastGen = (now.getTime() - lastGen.getTime()) / (1000 * 60 * 60)

      if (hoursSinceLastGen < 24) {
        const hoursRemaining = Math.ceil(24 - hoursSinceLastGen)
        return NextResponse.json(
          {
            success: false,
            error: `You can generate a new key in ${hoursRemaining} hours`,
            nextGenerationTime: new Date(lastGen.getTime() + 24 * 60 * 60 * 1000),
          },
          { status: 429 },
        )
      }
    }

    // Generate a unique key
    const keyPart1 = Math.random().toString(36).substring(2, 8).toUpperCase()
    const keyPart2 = Math.random().toString(36).substring(2, 8).toUpperCase()
    const keyPart3 = Math.random().toString(36).substring(2, 8).toUpperCase()

    const key = `VEXOS-${keyPart1}-${keyPart2}-${keyPart3}`

    // Set expiration date based on duration
    const expires = new Date()
    switch (duration) {
      case "1week":
        expires.setDate(expires.getDate() + 7)
        break
      case "1month":
        expires.setMonth(expires.getMonth() + 1)
        break
      case "1year":
        expires.setFullYear(expires.getFullYear() + 1)
        break
      case "lifetime":
        expires.setFullYear(expires.getFullYear() + 100) // 100 years is effectively lifetime
        break
      default: // 24h
        expires.setHours(expires.getHours() + 24)
    }

    // Store key in our "database"
    const keyId = uuidv4()
    keysDatabase[keyId] = {
      key,
      hwid,
      expires,
      used: false,
      createdAt: now,
      ip,
      keyType,
      duration,
      lastGenerated: now,
    }

    // Add to global key database
    keyDatabase[key] = {
      key,
      hwid,
      keyType,
      expiresAt: expires,
      createdAt: now,
      createdBy: "keysystem",
      isRevoked: false,
      revokedAt: null,
      revokedReason: null,
      usageCount: 0,
      lastUsed: null,
      metadata: {
        ip,
        duration,
        generatedVia: "keysystem",
      },
    }

    // Update last generation time for this HWID
    hwidLastGeneration[hwid] = now

    // For demonstration, log the key (in a real app, you'd store this securely)
    console.log(`Generated ${keyType} ${duration} key ${key} for HWID ${hwid}, expires ${expires}`)

    return NextResponse.json({
      success: true,
      key,
      expires,
      keyType,
      duration,
      message: `Key generated successfully. Valid for ${duration === "lifetime" ? "lifetime" : duration}.`,
      nextGenerationTime: keyType === "freemium" ? new Date(now.getTime() + 24 * 60 * 60 * 1000) : null,
    })
  } catch (error) {
    console.error("Error generating key:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to generate key",
      },
      { status: 500 },
    )
  }
}

