import { NextResponse } from "next/server"
import crypto from "crypto"

// In-memory database for IP to HWID mapping (in a real app, use a database)
const ipToHwidMap: Record<string, string> = {}

/**
 * Generates a HWID based on the client's IP address
 * Each IP address will always get the same HWID
 */
export async function POST(request: Request) {
  try {
    // Get client IP address
    const forwardedFor = request.headers.get("x-forwarded-for")
    const ip = forwardedFor ? forwardedFor.split(",")[0] : "unknown"

    // Check if this IP already has a HWID
    if (ipToHwidMap[ip]) {
      return NextResponse.json({
        success: true,
        hwid: ipToHwidMap[ip],
        message: "Retrieved existing HWID for this IP address",
      })
    }

    // Generate a new HWID
    // Create a hash from IP and a secret salt
    const hash = crypto.createHash("sha256")
    const salt = "vexos-secret-salt" // Default salt, no environment variable needed
    hash.update(ip + salt)

    // Format as XXXX-XXXX-XXXX-XXXX
    const hashHex = hash.digest("hex")
    const parts = []
    for (let i = 0; i < 4; i++) {
      parts.push(hashHex.substring(i * 4, i * 4 + 4).toUpperCase())
    }
    const hwid = parts.join("-")

    // Store the mapping
    ipToHwidMap[ip] = hwid

    return NextResponse.json({
      success: true,
      hwid,
      message: "Generated new HWID for this IP address",
    })
  } catch (error) {
    console.error("Error generating HWID:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to generate HWID",
      },
      { status: 500 },
    )
  }
}

