import { NextResponse } from "next/server"
import { premiumKeys } from "@/lib/premium-keys"

// In-memory database to store all verified keys and their usage
interface KeyUsageData {
  key: string
  hwid: string | null
  keyType: "premium" | "freemium"
  verificationCount: number
  lastVerified: Date
  firstVerified: Date
  ipAddresses: string[]
  isValid: boolean
  expiresAt: Date
  metadata: Record<string, any>
}

// Global in-memory database for key verification tracking
const keyVerificationDatabase: Record<string, KeyUsageData> = {}

// Global key database for tracking all keys
interface KeyRecord {
  key: string
  hwid: string
  keyType: "premium" | "freemium"
  expiresAt: Date
  createdAt: Date
  createdBy: string
  isRevoked: boolean
  revokedAt: Date | null
  revokedReason: string | null
  usageCount: number
  lastUsed: Date | null
  metadata: Record<string, any>
}

// Global in-memory database for all keys - this should be shared across routes
// In a real app, this would be in a database
const keyDatabase: Record<string, KeyRecord> = {}

// In a real application, this would be stored in a database
interface KeyData {
  key: string
  hwid: string
  expires: Date
  used: boolean
  createdAt: Date
  keyType: "premium" | "freemium"
  duration: "24h" | "1week" | "1month" | "1year" | "lifetime"
}

// Simulated database of regular keys
const keysDatabase: Record<string, KeyData> = {
  "VEXOS-ABC123-DEF456-GHI789": {
    key: "VEXOS-ABC123-DEF456-GHI789",
    hwid: "ABCD-1234-EFGH-5678",
    expires: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours from now
    used: false,
    createdAt: new Date(),
    keyType: "freemium",
    duration: "24h",
  },
}

// Initialize premium keys in the global database
function initializePremiumKeys() {
  Object.entries(premiumKeys).forEach(([keyString, keyData]) => {
    if (!keyDatabase[keyString]) {
      keyDatabase[keyString] = {
        key: keyString,
        hwid: "", // Will be set on first use
        keyType: "premium",
        expiresAt: keyData.expires,
        createdAt: new Date(),
        createdBy: "system",
        isRevoked: false,
        revokedAt: null,
        revokedReason: null,
        usageCount: 0,
        lastUsed: null,
        metadata: {
          duration: keyData.duration,
          source: "premium-keys.ts",
        },
      }
    }
  })
}

// Initialize the database with premium keys
initializePremiumKeys()

export async function GET(request: Request) {
  try {
    // Get the key and hwid from the URL query parameters
    const { searchParams } = new URL(request.url)
    const key = searchParams.get("key")
    const hwid = searchParams.get("hwid")
    const executorVersion = searchParams.get("version")

    // Get client IP address for tracking
    const forwardedFor = request.headers.get("x-forwarded-for")
    const ip = forwardedFor ? forwardedFor.split(",")[0] : "unknown"

    if (!key) {
      return NextResponse.json(
        {
          status: "invalid",
          error: "Missing key parameter",
        },
        { status: 400 },
      )
    }

    let isValid = false
    let expiresAt: Date | null = null
    let keyType: "premium" | "freemium" = "freemium"
    let errorMessage: string | null = null

    // First check if it's in the global key database
    if (key in keyDatabase) {
      const keyRecord = keyDatabase[key]
      expiresAt = keyRecord.expiresAt
      keyType = keyRecord.keyType

      // Check if key is revoked
      if (keyRecord.isRevoked) {
        isValid = false
        errorMessage = `Key has been revoked: ${keyRecord.revokedReason || "No reason provided"}`
      }
      // Check if key is expired
      else if (new Date() > keyRecord.expiresAt) {
        isValid = false
        errorMessage = "Key has expired"
      }
      // Key is valid
      else {
        isValid = true

        // Update usage stats
        keyRecord.usageCount += 1
        keyRecord.lastUsed = new Date()

        // Update HWID if provided and not already set
        if (hwid && !keyRecord.hwid) {
          keyRecord.hwid = hwid
        }
      }
    }
    // If not in global database, check premium keys
    else if (key in premiumKeys) {
      const premiumKey = premiumKeys[key]
      expiresAt = premiumKey.expires
      keyType = "premium"

      const isExpired = new Date() > premiumKey.expires
      isValid = !isExpired

      if (isExpired) {
        errorMessage = "Premium key has expired"
      } else {
        // Add to global database
        keyDatabase[key] = {
          key,
          hwid: hwid || "",
          keyType: "premium",
          expiresAt: premiumKey.expires,
          createdAt: new Date(Date.now() - 86400000), // Assume created 1 day ago
          createdBy: "system",
          isRevoked: false,
          revokedAt: null,
          revokedReason: null,
          usageCount: 1,
          lastUsed: new Date(),
          metadata: {
            duration: premiumKey.duration,
            source: "premium-keys.ts",
          },
        }
      }
    }
    // If not in global database or premium keys, check regular keys database
    else {
      const keyData = keysDatabase[key]

      if (!keyData) {
        errorMessage = "Key not found"
      } else {
        expiresAt = keyData.expires
        keyType = keyData.keyType

        // Check if key is expired
        const isExpired = new Date() > keyData.expires
        isValid = !isExpired

        if (isExpired) {
          errorMessage = "Key has expired"
        } else {
          // Add to global database
          keyDatabase[key] = {
            key,
            hwid: keyData.hwid,
            keyType: keyData.keyType,
            expiresAt: keyData.expires,
            createdAt: keyData.createdAt,
            createdBy: "system",
            isRevoked: false,
            revokedAt: null,
            revokedReason: null,
            usageCount: 1,
            lastUsed: new Date(),
            metadata: {
              duration: keyData.duration,
              source: "keysDatabase",
            },
          }
        }
      }
    }

    // Store verification data in our database
    if (key) {
      // Create or update key in database
      if (!keyVerificationDatabase[key]) {
        keyVerificationDatabase[key] = {
          key,
          hwid: hwid || null,
          keyType,
          verificationCount: 1,
          lastVerified: new Date(),
          firstVerified: new Date(),
          ipAddresses: [ip],
          isValid,
          expiresAt: expiresAt || new Date(),
          metadata: {
            executorVersion: executorVersion || "unknown",
            userAgent: request.headers.get("user-agent") || "unknown",
          },
        }
      } else {
        // Update existing key data
        const keyData = keyVerificationDatabase[key]
        keyData.verificationCount += 1
        keyData.lastVerified = new Date()
        keyData.isValid = isValid

        // Update HWID if provided and not already set
        if (hwid && !keyData.hwid) {
          keyData.hwid = hwid
        }

        // Add IP address if not already in the list
        if (!keyData.ipAddresses.includes(ip)) {
          keyData.ipAddresses.push(ip)
        }

        // Update metadata
        if (executorVersion) {
          keyData.metadata.executorVersion = executorVersion
        }
        keyData.metadata.userAgent = request.headers.get("user-agent") || "unknown"
      }

      // Log verification attempt (in a real app, you'd log to a database or file)
      console.log(`Key verification: ${key}, Valid: ${isValid}, IP: ${ip}, HWID: ${hwid || "not provided"}`)
    }

    // Return appropriate response based on validation result
    if (isValid) {
      return NextResponse.json(
        {
          status: "valid",
          "expires-at": expiresAt,
          stat: keyType,
          verification_count: keyVerificationDatabase[key].verificationCount,
        },
        { status: 200 },
      )
    } else {
      return NextResponse.json(
        {
          status: "invalid",
          error: errorMessage || "Invalid key",
          "expires-at": expiresAt,
        },
        { status: 200 },
      )
    }
  } catch (error) {
    console.error("Error verifying key:", error)
    return NextResponse.json(
      {
        status: "invalid",
        error: "Failed to verify key",
      },
      { status: 500 },
    )
  }
}

// Add a new endpoint to get all verification data (admin only)
export async function POST(request: Request) {
  try {
    const { adminKey } = await request.json()

    // Check admin authentication (in a real app, use a more secure method)
    if (adminKey !== "VEXOS-ADMIN-KEY") {
      return NextResponse.json(
        {
          success: false,
          error: "Unauthorized access",
        },
        { status: 401 },
      )
    }

    // Return the entire verification database
    return NextResponse.json({
      success: true,
      total_keys: Object.keys(keyVerificationDatabase).length,
      keys: keyVerificationDatabase,
    })
  } catch (error) {
    console.error("Error accessing verification database:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to access verification database",
      },
      { status: 500 },
    )
  }
}

