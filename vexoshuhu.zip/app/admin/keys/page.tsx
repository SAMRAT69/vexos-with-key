"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CheckCircle, AlertTriangle, Lock, Shield, Database, RefreshCw, Search, Filter, X, Check } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

// Admin key - in a real app, this would be stored securely
const ADMIN_KEY = "VEXOS-ADMIN-KEY"

export default function KeyDatabasePage() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [keys, setKeys] = useState<any[]>([])
  const [totalKeys, setTotalKeys] = useState(0)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [adminPassword, setAdminPassword] = useState("")

  const authenticate = () => {
    // In a real app, this would be a secure authentication process
    if (adminPassword === "vexosadmin") {
      setIsAuthenticated(true)
      loadKeys()
    } else {
      setError("Invalid admin password")
    }
  }

  const loadKeys = async () => {
    setIsLoading(true)
    setError("")

    try {
      const response = await fetch(`/v1/keys/database?adminKey=${ADMIN_KEY}`)
      const data = await response.json()

      if (response.ok) {
        setKeys(data.keys)
        setTotalKeys(data.total)
      } else {
        setError(data.error || "Failed to load key database")
      }
    } catch (err: any) {
      setError(err.message || "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const revokeKey = async (key: string) => {
    if (!confirm("Are you sure you want to revoke this key?")) return

    setIsLoading(true)
    setError("")
    setSuccess("")

    try {
      const response = await fetch("/v1/keys/database", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          adminKey: ADMIN_KEY,
          action: "revoke",
          key,
          data: {
            reason: "Revoked by admin",
          },
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setSuccess(`Key ${key} revoked successfully`)
        loadKeys() // Reload keys
      } else {
        setError(data.error || "Failed to revoke key")
      }
    } catch (err: any) {
      setError(err.message || "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const filteredKeys = keys.filter((key) => {
    // Apply search filter
    if (searchQuery && !key.key.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false
    }

    // Apply type filter
    if (filterType === "premium" && key.keyType !== "premium") return false
    if (filterType === "freemium" && key.keyType !== "freemium") return false
    if (filterType === "revoked" && !key.isRevoked) return false
    if (filterType === "active" && key.isRevoked) return false

    return true
  })

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col min-h-screen bg-gradient-to-b from-slate-900 via-slate-900 to-black">
        <Navbar />

        <div className="fixed inset-0 z-0">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(124,58,237,0.15),transparent_50%)]"></div>
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(244,63,94,0.15),transparent_50%)]"></div>
        </div>

        <main className="flex-1 pt-24 relative z-10 flex items-center justify-center">
          <Card className="w-full max-w-md border-slate-800/50 bg-slate-900/50 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center">
                  <Shield className="h-5 w-5 text-purple-500" />
                </div>
                <div>
                  <CardTitle>Admin Authentication</CardTitle>
                  <CardDescription>Enter your admin password to continue</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-4">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="password">Admin Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter admin password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                onClick={authenticate}
              >
                <Lock className="mr-2 h-4 w-4" />
                Authenticate
              </Button>
            </CardFooter>
          </Card>
        </main>

        <Footer />
      </div>
    )
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-slate-900 via-slate-900 to-black">
      <Navbar />

      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(124,58,237,0.15),transparent_50%)]"></div>
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(244,63,94,0.15),transparent_50%)]"></div>
      </div>

      <main className="flex-1 pt-24 relative z-10">
        <div className="container px-4 mx-auto py-12">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-white via-purple-400 to-pink-500 inline-block">
                Key Database Management
              </h1>
              <p className="text-slate-400">View and manage all VEXOS keys</p>
            </div>

            <div className="flex items-center gap-3">
              <Badge variant="outline" className="bg-slate-900/50 text-purple-400 border-purple-500/30 px-3 py-1.5">
                <Database className="mr-1 h-3.5 w-3.5" />
                {totalKeys} Total Keys
              </Badge>

              <Button variant="outline" size="sm" onClick={loadKeys} disabled={isLoading}>
                <RefreshCw className={`mr-1 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
                Refresh
              </Button>
            </div>
          </div>

          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mb-6 border-green-500 bg-green-500/10">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <AlertDescription className="text-green-500">{success}</AlertDescription>
            </Alert>
          )}

          <Card className="border-slate-800/50 bg-slate-900/50 backdrop-blur-sm mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5 text-purple-500" />
                Search & Filter
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                    <Input
                      placeholder="Search by key..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                    {searchQuery && (
                      <button
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                        onClick={() => setSearchQuery("")}
                      >
                        <X className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>

                <div>
                  <Tabs defaultValue="all" value={filterType} onValueChange={setFilterType}>
                    <TabsList className="grid grid-cols-5 w-full">
                      <TabsTrigger value="all">All</TabsTrigger>
                      <TabsTrigger value="premium">Premium</TabsTrigger>
                      <TabsTrigger value="freemium">Freemium</TabsTrigger>
                      <TabsTrigger value="active">Active</TabsTrigger>
                      <TabsTrigger value="revoked">Revoked</TabsTrigger>
                    </TabsList>
                  </Tabs>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-800/50 bg-slate-900/50 backdrop-blur-sm">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Key</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>HWID</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Expires</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredKeys.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-slate-500">
                          {isLoading ? (
                            <div className="flex items-center justify-center gap-2">
                              <RefreshCw className="h-4 w-4 animate-spin" />
                              Loading keys...
                            </div>
                          ) : (
                            "No keys found matching your filters"
                          )}
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredKeys.map((keyData) => (
                        <TableRow key={keyData.key}>
                          <TableCell className="font-mono text-xs">{keyData.key}</TableCell>
                          <TableCell>
                            <Badge
                              variant={keyData.keyType === "premium" ? "default" : "secondary"}
                              className={
                                keyData.keyType === "premium"
                                  ? "bg-purple-500/20 text-purple-400 hover:bg-purple-500/30 border border-purple-500/30"
                                  : "bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 border border-blue-500/30"
                              }
                            >
                              {keyData.keyType}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {keyData.isRevoked ? (
                              <Badge
                                variant="destructive"
                                className="bg-red-500/20 text-red-400 hover:bg-red-500/30 border border-red-500/30"
                              >
                                Revoked
                              </Badge>
                            ) : (
                              <Badge
                                variant="outline"
                                className="bg-green-500/20 text-green-400 hover:bg-green-500/30 border border-green-500/30"
                              >
                                <Check className="mr-1 h-3 w-3" />
                                Active
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell className="font-mono text-xs">{keyData.hwid || "Not bound"}</TableCell>
                          <TableCell>{new Date(keyData.createdAt).toLocaleDateString()}</TableCell>
                          <TableCell>{new Date(keyData.expiresAt).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {!keyData.isRevoked && (
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => revokeKey(keyData.key)}
                                  className="h-8 px-2 text-xs"
                                >
                                  Revoke
                                </Button>
                              )}
                              <Button variant="outline" size="sm" className="h-8 px-2 text-xs">
                                Details
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />

      <style jsx global>{`
        .badge-premium {
          background-color: rgba(124, 58, 237, 0.2);
          color: #a78bfa;
          border-color: rgba(124, 58, 237, 0.3);
        }
        
        .badge-freemium {
          background-color: rgba(59, 130, 246, 0.2);
          color: #93c5fd;
          border-color: rgba(59, 130, 246, 0.3);
        }
      `}</style>
    </div>
  )
}

