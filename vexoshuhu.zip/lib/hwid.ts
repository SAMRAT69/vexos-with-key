/**
 * Generates a hardware ID (HWID) based on browser and device information
 * This is a simplified version for demonstration purposes
 * In a real application, you would use more sophisticated methods
 */
export function generateHWID(): string {
  const components = [
    navigator.userAgent,
    navigator.language,
    screen.colorDepth,
    screen.width + "x" + screen.height,
    new Date().getTimezoneOffset(),
    navigator.hardwareConcurrency,
    navigator.deviceMemory,
    navigator.platform,
  ]

  // Create a hash from the components
  let hash = 0
  const combinedString = components.join("|")

  for (let i = 0; i < combinedString.length; i++) {
    const char = combinedString.charCodeAt(i)
    hash = (hash << 5) - hash + char
    hash = hash & hash // Convert to 32bit integer
  }

  // Convert to hexadecimal and ensure it's always positive
  const hexHash = Math.abs(hash).toString(16).padStart(8, "0")

  // Format as XXXX-XXXX-XXXX-XXXX
  const parts = []
  for (let i = 0; i < 4; i++) {
    parts.push(hexHash.substring(i * 2, i * 2 + 4).padEnd(4, "0"))
  }

  return parts.join("-").toUpperCase()
}

/**
 * Validates if a HWID matches the current device
 */
export function validateHWID(storedHWID: string): boolean {
  const currentHWID = generateHWID()
  return storedHWID === currentHWID
}

