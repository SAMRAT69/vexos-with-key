// This file contains hardcoded premium keys that only developers can add
// In a real application, you would use a secure database instead

interface PremiumKey {
  key: string
  keyType: "premium"
  duration: "1week" | "1month" | "1year" | "lifetime"
  expires: Date
}

// Hardcoded premium keys - only developers can add these
export const premiumKeys: Record<string, PremiumKey> = {
  "VEXOS-PREMIUM-WEEK-123456": {
    key: "VEXOS-PREMIUM-WEEK-123456",
    keyType: "premium",
    duration: "1week",
    expires: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 1 week from now
  },
  "VEXOS-PREMIUM-MONTH-123456": {
    key: "VEXOS-PREMIUM-MONTH-123456",
    keyType: "premium",
    duration: "1month",
    expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 1 month from now
  },
  "VEXOS-PREMIUM-YEAR-123456": {
    key: "VEXOS-PREMIUM-YEAR-123456",
    keyType: "premium",
    duration: "1year",
    expires: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year from now
  },
  "VEXOS-PREMIUM-LIFETIME-123456": {
    key: "VEXOS-PREMIUM-LIFETIME-123456",
    keyType: "premium",
    duration: "lifetime",
    expires: new Date(Date.now() + 100 * 365 * 24 * 60 * 60 * 1000), // 100 years (effectively lifetime)
  },
}

// Function to check if a key is a valid premium key
export function isPremiumKey(key: string): boolean {
  return key in premiumKeys
}

// Function to get premium key details
export function getPremiumKeyDetails(key: string): PremiumKey | null {
  return premiumKeys[key] || null
}

